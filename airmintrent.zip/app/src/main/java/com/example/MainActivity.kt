package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.example.data.AppRepository
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme

enum class NavigationTarget {
    MAIN, ADMIN, PRIVACY, AI_CHAT
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        // Single unified data repository instance
        val repository = AppRepository.getInstance(applicationContext)

        setContent {
            MyApplicationTheme {
                val currentUser by repository.currentUser.collectAsState()
                var currentNavigationState by remember { mutableStateOf(NavigationTarget.MAIN) }

                if (currentUser == null) {
                    // Force login if no active creator profile session exists
                    AuthScreen(
                        repository = repository,
                        onAuthSuccess = {
                            currentNavigationState = NavigationTarget.MAIN
                        }
                    )
                } else {
                    // Animated Navigation screen layouts transitions
                    AnimatedContent(
                        targetState = currentNavigationState,
                        modifier = Modifier.fillMaxSize(),
                        label = "ScreenTransition"
                    ) { target ->
                        when (target) {
                            NavigationTarget.MAIN -> {
                                MainLayout(
                                    repository = repository,
                                    onNavigateToAI = { currentNavigationState = NavigationTarget.AI_CHAT },
                                    onNavigateToSafety = { currentNavigationState = NavigationTarget.PRIVACY },
                                    onNavigateToAdmin = { currentNavigationState = NavigationTarget.ADMIN },
                                    onLogout = {
                                        repository.logout()
                                    }
                                )
                            }
                            NavigationTarget.PRIVACY -> {
                                PrivacyScreen(
                                    repository = repository,
                                    onBack = { currentNavigationState = NavigationTarget.MAIN }
                                )
                            }
                            NavigationTarget.AI_CHAT -> {
                                AIChatScreen(
                                    repository = repository,
                                    onBack = { currentNavigationState = NavigationTarget.MAIN }
                                )
                            }
                            NavigationTarget.ADMIN -> {
                                AdminScreen(
                                    repository = repository,
                                    onBack = { currentNavigationState = NavigationTarget.MAIN }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
