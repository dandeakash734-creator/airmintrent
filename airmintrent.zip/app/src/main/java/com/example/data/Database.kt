package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// --- Entities ---

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val username: String,
    val passwordHash: String,
    val fullName: String,
    val bio: String,
    val profilePicUrl: String,
    val isPrivate: Boolean = false,
    val isBanned: Boolean = false,
    val followersCount: Int = 0,
    val followingCount: Int = 0
)

@Entity(tableName = "follows", indices = [Index(value = ["followerUsername", "followingUsername"], unique = true)])
data class FollowEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val followerUsername: String,
    val followingUsername: String
)

@Entity(tableName = "posts")
data class PostEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val authorUsername: String,
    val authorName: String,
    val authorProfilePic: String,
    val content: String,
    val mediaUrl: String,
    val mediaType: String, // "TEXT", "IMAGE", "VIDEO"
    val timestamp: Long = System.currentTimeMillis(),
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val isReported: Boolean = false,
    val isSpam: Boolean = false,
    val location: String = ""
)

@Entity(tableName = "comments")
data class CommentEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val postId: Int,
    val username: String,
    val authorName: String,
    val authorProfilePic: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "likes", indices = [Index(value = ["postId", "username"], unique = true)])
data class LikeEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val postId: Int,
    val username: String
)

@Entity(tableName = "reels")
data class ReelEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val authorUsername: String,
    val authorName: String,
    val authorProfilePic: String,
    val content: String,
    val videoUrl: String,
    val audioTrack: String,
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "stories")
data class StoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val authorUsername: String,
    val authorName: String,
    val authorProfilePic: String,
    val mediaUrl: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val senderUsername: String,
    val receiverUsername: String,
    val content: String,
    val isVoice: Boolean = false,
    val voiceDuration: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val recipientUsername: String,
    val senderUsername: String,
    val type: String, // "LIKE", "COMMENT", "FOLLOW", "MESSAGE"
    val message: String,
    val postId: Int? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "reports")
data class ReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val reporterUsername: String,
    val reportedType: String, // "USER", "POST"
    val targetId: String, // username or postId string
    val reason: String,
    val status: String = "PENDING", // "PENDING", "RESOLVED"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "blocks", indices = [Index(value = ["blockerUsername", "blockedUsername"], unique = true)])
data class BlockEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val blockerUsername: String,
    val blockedUsername: String
)

// --- DAO ---

@Dao
interface AppDao {
    // Users
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): UserEntity?

    @Query("SELECT * FROM users")
    fun getAllUsersFlow(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE username LIKE :query OR fullName LIKE :query")
    suspend fun searchUsers(query: String): List<UserEntity>

    // Follows
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFollow(follow: FollowEntity)

    @Query("DELETE FROM follows WHERE followerUsername = :follower AND followingUsername = :following")
    suspend fun deleteFollow(follower: String, following: String)

    @Query("SELECT * FROM follows WHERE followerUsername = :username")
    fun getFollowingFlow(username: String): Flow<List<FollowEntity>>

    @Query("SELECT * FROM follows WHERE followingUsername = :username")
    fun getFollowersFlow(username: String): Flow<List<FollowEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM follows WHERE followerUsername = :follower AND followingUsername = :following)")
    fun isFollowingFlow(follower: String, following: String): Flow<Boolean>

    @Query("SELECT EXISTS(SELECT 1 FROM follows WHERE followerUsername = :follower AND followingUsername = :following)")
    suspend fun isFollowing(follower: String, following: String): Boolean

    // Posts
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: PostEntity): Long

    @Update
    suspend fun updatePost(post: PostEntity)

    @Query("DELETE FROM posts WHERE id = :postId")
    suspend fun deletePost(postId: Int)

    @Query("SELECT * FROM posts WHERE id = :postId LIMIT 1")
    suspend fun getPostById(postId: Int): PostEntity?

    @Query("SELECT * FROM posts ORDER BY timestamp DESC")
    fun getAllPostsFlow(): Flow<List<PostEntity>>

    @Query("SELECT * FROM posts WHERE content LIKE :query OR authorUsername LIKE :query ORDER BY timestamp DESC")
    suspend fun searchPosts(query: String): List<PostEntity>

    // Likes
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertLike(like: LikeEntity): Long

    @Query("DELETE FROM likes WHERE postId = :postId AND username = :username")
    suspend fun deleteLike(postId: Int, username: String)

    @Query("SELECT EXISTS(SELECT 1 FROM likes WHERE postId = :postId AND username = :username)")
    fun isPostLikedFlow(postId: Int, username: String): Flow<Boolean>

    @Query("SELECT EXISTS(SELECT 1 FROM likes WHERE postId = :postId AND username = :username)")
    suspend fun isPostLiked(postId: Int, username: String): Boolean

    // Comments
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: CommentEntity)

    @Query("SELECT * FROM comments WHERE postId = :postId ORDER BY timestamp ASC")
    fun getCommentsForPostFlow(postId: Int): Flow<List<CommentEntity>>

    // Reels
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReel(reel: ReelEntity)

    @Query("SELECT * FROM reels ORDER BY timestamp DESC")
    fun getAllReelsFlow(): Flow<List<ReelEntity>>

    // Stories
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: StoryEntity)

    @Query("SELECT * FROM stories WHERE id = :id LIMIT 1")
    suspend fun getStoryById(id: Int): StoryEntity?

    // active within 24h stories
    @Query("SELECT * FROM stories WHERE timestamp >= :since ORDER BY timestamp ASC")
    fun getActiveStoriesFlow(since: Long): Flow<List<StoryEntity>>

    // Messages
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    @Query("SELECT * FROM messages WHERE (senderUsername = :u1 AND receiverUsername = :u2) OR (senderUsername = :u2 AND receiverUsername = :u1) ORDER BY timestamp ASC")
    fun getMessagesBetweenUsersFlow(u1: String, u2: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE senderUsername = :user OR receiverUsername = :user ORDER BY timestamp DESC")
    fun getAllUserMessagesFlow(user: String): Flow<List<MessageEntity>>

    // Notifications
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("SELECT * FROM notifications WHERE recipientUsername = :username ORDER BY timestamp DESC")
    fun getNotificationsFlow(username: String): Flow<List<NotificationEntity>>

    @Query("DELETE FROM notifications WHERE recipientUsername = :username")
    suspend fun clearUserNotifications(username: String)

    // Reports
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: ReportEntity)

    @Query("SELECT * FROM reports ORDER BY timestamp DESC")
    fun getAllReportsFlow(): Flow<List<ReportEntity>>

    @Update
    suspend fun updateReport(report: ReportEntity)

    // Blocks
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertBlock(block: BlockEntity)

    @Query("DELETE FROM blocks WHERE blockerUsername = :blocker AND blockedUsername = :blocked")
    suspend fun deleteBlock(blocker: String, blocked: String)

    @Query("SELECT blockedUsername FROM blocks WHERE blockerUsername = :username")
    fun getBlockedUsernamesFlow(username: String): Flow<List<String>>

    @Query("SELECT EXISTS(SELECT 1 FROM blocks WHERE blockerUsername = :blocker AND blockedUsername = :blocked)")
    suspend fun isBlocked(blocker: String, blocked: String): Boolean

    @Query("DELETE FROM users WHERE username = :username")
    suspend fun deleteUserByUsername(username: String)

    @Query("UPDATE posts SET authorUsername = :newUsername, authorName = :newName, authorProfilePic = :newPic WHERE authorUsername = :oldUsername")
    suspend fun updatePostAuthorRef(oldUsername: String, newUsername: String, newName: String, newPic: String)

    @Query("UPDATE comments SET username = :newUsername, authorName = :newName, authorProfilePic = :newPic WHERE username = :oldUsername")
    suspend fun updateCommentAuthorRef(oldUsername: String, newUsername: String, newName: String, newPic: String)

    @Query("UPDATE reels SET authorUsername = :newUsername, authorName = :newName, authorProfilePic = :newPic WHERE authorUsername = :oldUsername")
    suspend fun updateReelAuthorRef(oldUsername: String, newUsername: String, newName: String, newPic: String)

    @Query("UPDATE stories SET authorUsername = :newUsername, authorName = :newName, authorProfilePic = :newPic WHERE authorUsername = :oldUsername")
    suspend fun updateStoryAuthorRef(oldUsername: String, newUsername: String, newName: String, newPic: String)

    @Query("UPDATE messages SET senderUsername = :newUsername WHERE senderUsername = :oldUsername")
    suspend fun updateMessageSenderRef(oldUsername: String, newUsername: String)

    @Query("UPDATE messages SET receiverUsername = :newUsername WHERE receiverUsername = :oldUsername")
    suspend fun updateMessageReceiverRef(oldUsername: String, newUsername: String)

    @Query("UPDATE notifications SET recipientUsername = :newUsername WHERE recipientUsername = :oldUsername")
    suspend fun updateNotificationRecipientRef(oldUsername: String, newUsername: String)

    @Query("UPDATE notifications SET senderUsername = :newUsername WHERE senderUsername = :oldUsername")
    suspend fun updateNotificationSenderRef(oldUsername: String, newUsername: String)
}

// --- Database Holder ---

@Database(
    entities = [
        UserEntity::class,
        FollowEntity::class,
        PostEntity::class,
        CommentEntity::class,
        LikeEntity::class,
        ReelEntity::class,
        StoryEntity::class,
        MessageEntity::class,
        NotificationEntity::class,
        ReportEntity::class,
        BlockEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao
}
