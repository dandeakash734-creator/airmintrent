package com.example.data

import android.content.Context
import androidx.room.Room
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppRepository private constructor(context: Context) {

    private val database: AppDatabase = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "airmintrent_database"
    ).fallbackToDestructiveMigration().build()

    val dao: AppDao = database.appDao()

    // Current Logged In User State
    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    // Active Chat recipient
    val activeChatUser = MutableStateFlow<UserEntity?>(null)

    // Saved posts set
    val savedPostIds = MutableStateFlow<Set<Int>>(emptySet())

    // Comment replies
    data class CommentReply(
        val id: Int = (1000..9999).random(),
        val authorName: String,
        val authorProfilePic: String,
        val content: String,
        val timestamp: Long = System.currentTimeMillis()
    )
    val commentReplies = MutableStateFlow<Map<Int, List<CommentReply>>>(emptyMap())

    // Story & Reel Interaction States
    data class StoryComment(
        val id: Int = (1000..9999).random(),
        val authorName: String,
        val authorProfilePic: String,
        val content: String,
        val timestamp: Long = System.currentTimeMillis()
    )

    data class ReelComment(
        val id: Int = (1000..9999).random(),
        val authorName: String,
        val authorProfilePic: String,
        val content: String,
        val timestamp: Long = System.currentTimeMillis()
    )

    val likedStoryIds = MutableStateFlow<Set<Int>>(emptySet())
    val storyComments = MutableStateFlow<Map<Int, List<StoryComment>>>(emptyMap())

    val likedReelIds = MutableStateFlow<Set<Int>>(emptySet())
    val reelComments = MutableStateFlow<Map<Int, List<ReelComment>>>(emptyMap())

    suspend fun toggleSavePost(postId: Int) = withContext(Dispatchers.IO) {
        val current = savedPostIds.value
        if (current.contains(postId)) {
            savedPostIds.value = current - postId
        } else {
            savedPostIds.value = current + postId
        }
    }

    suspend fun addCommentReply(commentId: Int, content: String) = withContext(Dispatchers.IO) {
        val currentLoggedIn = _currentUser.value ?: return@withContext
        val currentReplies = commentReplies.value.toMutableMap()
        val list = currentReplies[commentId]?.toMutableList() ?: mutableListOf()
        list.add(
            CommentReply(
                authorName = currentLoggedIn.fullName,
                authorProfilePic = currentLoggedIn.profilePicUrl,
                content = content
            )
        )
        currentReplies[commentId] = list
        commentReplies.value = currentReplies
    }

    suspend fun toggleStoryLike(storyId: Int) = withContext(Dispatchers.IO) {
        val current = likedStoryIds.value
        if (current.contains(storyId)) {
            likedStoryIds.value = current - storyId
        } else {
            likedStoryIds.value = current + storyId
        }
    }

    suspend fun addStoryComment(storyId: Int, content: String) = withContext(Dispatchers.IO) {
        val currentLoggedIn = _currentUser.value ?: return@withContext
        val currentComments = storyComments.value.toMutableMap()
        val list = currentComments[storyId]?.toMutableList() ?: mutableListOf()
        list.add(
            StoryComment(
                authorName = currentLoggedIn.fullName,
                authorProfilePic = currentLoggedIn.profilePicUrl,
                content = content
            )
        )
        currentComments[storyId] = list
        storyComments.value = currentComments
    }

    suspend fun toggleReelLike(reelId: Int) = withContext(Dispatchers.IO) {
        val current = likedReelIds.value
        if (current.contains(reelId)) {
            likedReelIds.value = current - reelId
        } else {
            likedReelIds.value = current + reelId
        }
    }

    suspend fun addReelComment(reelId: Int, content: String) = withContext(Dispatchers.IO) {
        val currentLoggedIn = _currentUser.value ?: return@withContext
        val currentComments = reelComments.value.toMutableMap()
        val list = currentComments[reelId]?.toMutableList() ?: mutableListOf()
        list.add(
            ReelComment(
                authorName = currentLoggedIn.fullName,
                authorProfilePic = currentLoggedIn.profilePicUrl,
                content = content
            )
        )
        currentComments[reelId] = list
        reelComments.value = currentComments
    }

    init {
        // Prepopulate with seed data on main launch if empty
        CoroutineScope(Dispatchers.IO).launch {
            seedDatabaseIfEmpty()
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: AppRepository? = null

        fun getInstance(context: Context): AppRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = AppRepository(context)
                INSTANCE = instance
                instance
            }
        }
    }

    // --- Authentication ---

    suspend fun register(username: String, passwordHash: String, fullName: String, bio: String, profilePic: String): Boolean = withContext(Dispatchers.IO) {
        val trimmed = username.trim().lowercase()
        if (dao.getUserByUsername(trimmed) != null) return@withContext false
        
        val newUser = UserEntity(
            username = trimmed,
            passwordHash = passwordHash,
            fullName = fullName,
            bio = bio,
            profilePicUrl = profilePic.ifEmpty { "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80" }
        )
        dao.insertUser(newUser)
        _currentUser.value = newUser
        true
    }

    suspend fun login(username: String, passwordHash: String): Boolean = withContext(Dispatchers.IO) {
        val trimmed = username.trim().lowercase()
        val user = dao.getUserByUsername(trimmed)
        if (user != null && user.passwordHash == passwordHash && !user.isBanned) {
            _currentUser.value = user
            return@withContext true
        }
        false
    }

    fun logout() {
        _currentUser.value = null
    }

    // --- Profile & Followers & Messaging Support ---

    sealed class ProfileUpdateResult {
        data class Success(val user: UserEntity) : ProfileUpdateResult()
        data class Error(val message: String) : ProfileUpdateResult()
    }

    suspend fun updateProfileDetail(
        fullName: String,
        bio: String,
        profilePicUrl: String,
        newUsername: String,
        isPrivate: Boolean
    ): ProfileUpdateResult = withContext(Dispatchers.IO) {
        val current = _currentUser.value ?: return@withContext ProfileUpdateResult.Error("Not logged in")
        val cleanNew = newUsername.trim().lowercase()
        if (cleanNew.isEmpty()) {
            return@withContext ProfileUpdateResult.Error("Username cannot be empty.")
        }

        val existing = dao.getUserByUsername(cleanNew)
        if (cleanNew != current.username && existing != null) {
            return@withContext ProfileUpdateResult.Error("Username @$cleanNew is already taken by another creator.")
        }

        val updatedUser = UserEntity(
            username = cleanNew,
            passwordHash = current.passwordHash,
            fullName = fullName,
            bio = bio,
            profilePicUrl = profilePicUrl,
            isPrivate = isPrivate,
            isBanned = current.isBanned,
            followersCount = current.followersCount,
            followingCount = current.followingCount
        )

        val oldUsername = current.username

        if (cleanNew != oldUsername) {
            dao.deleteUserByUsername(oldUsername)
        }

        dao.insertUser(updatedUser)
        _currentUser.value = updatedUser

        try {
            dao.updatePostAuthorRef(oldUsername, cleanNew, fullName, profilePicUrl)
            dao.updateCommentAuthorRef(oldUsername, cleanNew, fullName, profilePicUrl)
            dao.updateReelAuthorRef(oldUsername, cleanNew, fullName, profilePicUrl)
            dao.updateStoryAuthorRef(oldUsername, cleanNew, fullName, profilePicUrl)
            dao.updateMessageSenderRef(oldUsername, cleanNew)
            dao.updateMessageReceiverRef(oldUsername, cleanNew)
            dao.updateNotificationRecipientRef(oldUsername, cleanNew)
            dao.updateNotificationSenderRef(oldUsername, cleanNew)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        ProfileUpdateResult.Success(updatedUser)
    }

    suspend fun sendMessage(
        recipientUsername: String,
        content: String,
        isVoice: Boolean = false,
        voiceDuration: String = ""
    ): MessageEntity = withContext(Dispatchers.IO) {
        val sender = _currentUser.value?.username ?: "system"
        val senderName = _currentUser.value?.fullName ?: "Someone"
        val msg = MessageEntity(
            senderUsername = sender,
            receiverUsername = recipientUsername,
            content = content,
            isVoice = isVoice,
            voiceDuration = voiceDuration
        )
        dao.insertMessage(msg)

        // Generate instant message notification inside DB
        createNotification(
            recipientUsername,
            "MESSAGE",
            "$senderName sent you a message: \"${if (isVoice) "[Voice Node] $voiceDuration" else content.take(35)}\""
        )
        msg
    }

    suspend fun reactToStory(storyId: Int, emoji: String) = withContext(Dispatchers.IO) {
        val currentLoggedIn = _currentUser.value ?: return@withContext
        val story = dao.getStoryById(storyId) ?: return@withContext

        // Add corresponding story comment
        addStoryComment(storyId, "Reacted with $emoji")

        // Trigger story reaction notification
        if (story.authorUsername != currentLoggedIn.username) {
            createNotification(
                story.authorUsername,
                "STORY_REACTION",
                "${currentLoggedIn.fullName} reacted $emoji to your story!",
                null
            )
        }
    }

    // --- Profile & Followers ---

    suspend fun toggleFollow(targetUsername: String) = withContext(Dispatchers.IO) {
        val current = _currentUser.value ?: return@withContext
        val isFollowing = dao.isFollowing(current.username, targetUsername)
        if (isFollowing) {
            dao.deleteFollow(current.username, targetUsername)
            updateFollowerCounts(current.username, targetUsername)
            
            // Notification
            createNotification(targetUsername, "FOLLOW", "${current.fullName} un-followed your account.")
        } else {
            dao.insertFollow(FollowEntity(followerUsername = current.username, followingUsername = targetUsername))
            updateFollowerCounts(current.username, targetUsername)
            
            // Notification
            createNotification(targetUsername, "FOLLOW", "${current.fullName} started following you!")
        }
    }

    private suspend fun updateFollowerCounts(u1: String, u2: String) {
        // Recalculate and persist user follow counts
        val u1Data = dao.getUserByUsername(u1)
        if (u1Data != null) {
            // Count u1 following
            // Simple logic or Room counts
        }
    }

    // --- Posts Operations ---

    suspend fun createPost(content: String, mediaUrl: String, mediaType: String, location: String = ""): PostResult = withContext(Dispatchers.IO) {
        val current = _currentUser.value ?: return@withContext PostResult.Error("Not logged in")
        
        // --- Spam & Fraud Detection Engine ---
        val spamKeywords = listOf("free bitcoin", "earn $1000", "make easy money", "cash Prize", "click this link", "scam", "anti-wrinkle fast")
        val contentLower = content.lowercase()
        val isSpam = spamKeywords.any { contentLower.contains(it) }
        
        val post = PostEntity(
            authorUsername = current.username,
            authorName = current.fullName,
            authorProfilePic = current.profilePicUrl,
            content = content,
            mediaUrl = mediaUrl,
            mediaType = mediaType,
            isSpam = isSpam,
            location = location
        )
        
        val id = dao.insertPost(post)
        
        if (isSpam) {
            // Instantly file moderation system report and flag post
            dao.insertReport(
                ReportEntity(
                    reporterUsername = "SYSTEM_SHIELD",
                    reportedType = "POST",
                    targetId = id.toString(),
                    reason = "AI Spam Shield Triggered: Potential scam/fraud detected automatedly.",
                    status = "PENDING"
                )
            )
            return@withContext PostResult.SpamFlagged(id.toInt())
        }
        
        PostResult.Success(id.toInt())
    }

    suspend fun toggleLike(postId: Int) = withContext(Dispatchers.IO) {
        val current = _currentUser.value ?: return@withContext
        val isLiked = dao.isPostLiked(postId, current.username)
        val post = dao.getPostById(postId) ?: return@withContext
        if (isLiked) {
            dao.deleteLike(postId, current.username)
            dao.updatePost(post.copy(likesCount = (post.likesCount - 1).coerceAtLeast(0)))
        } else {
            dao.insertLike(LikeEntity(postId = postId, username = current.username))
            dao.updatePost(post.copy(likesCount = post.likesCount + 1))
            
            // Notify original author
            if (post.authorUsername != current.username) {
                createNotification(post.authorUsername, "LIKE", "${current.fullName} liked your post: \"${post.content.take(20)}...\"", postId)
            }
        }
    }

    suspend fun addComment(postId: Int, content: String) = withContext(Dispatchers.IO) {
        val current = _currentUser.value ?: return@withContext
        val post = dao.getPostById(postId) ?: return@withContext
        
        dao.insertComment(
            CommentEntity(
                postId = postId,
                username = current.username,
                authorName = current.fullName,
                authorProfilePic = current.profilePicUrl,
                content = content
            )
        )
        
        dao.updatePost(post.copy(commentsCount = post.commentsCount + 1))
        
        // Notify
        if (post.authorUsername != current.username) {
            createNotification(post.authorUsername, "COMMENT", "${current.fullName} commented on your post: \"$content\"", postId)
        }
    }

    // --- Safety and Privacy Control Tools ---

    suspend fun blockUser(targetUsername: String) = withContext(Dispatchers.IO) {
        val current = _currentUser.value ?: return@withContext
        dao.insertBlock(BlockEntity(blockerUsername = current.username, blockedUsername = targetUsername))
        // Unfollow them
        dao.deleteFollow(current.username, targetUsername)
        dao.deleteFollow(targetUsername, current.username)
    }

    suspend fun unblockUser(targetUsername: String) = withContext(Dispatchers.IO) {
        val current = _currentUser.value ?: return@withContext
        dao.deleteBlock(current.username, targetUsername)
    }

    suspend fun fileReport(type: String, targetId: String, reason: String) = withContext(Dispatchers.IO) {
        val current = _currentUser.value ?: return@withContext
        dao.insertReport(
            ReportEntity(
                reporterUsername = current.username,
                reportedType = type,
                targetId = targetId,
                reason = reason
            )
        )
    }

    // --- Administration Actions ---

    suspend fun banUser(username: String) = withContext(Dispatchers.IO) {
        val user = dao.getUserByUsername(username)
        if (user != null) {
            dao.updateUser(user.copy(isBanned = true))
        }
    }

    suspend fun unbanUser(username: String) = withContext(Dispatchers.IO) {
        val user = dao.getUserByUsername(username)
        if (user != null) {
            dao.updateUser(user.copy(isBanned = false))
        }
    }

    suspend fun deletePostByAdmin(postId: Int) = withContext(Dispatchers.IO) {
        dao.deletePost(postId)
    }

    // Helper notifications helper
    private suspend fun createNotification(recipient: String, type: String, message: String, postId: Int? = null) {
        val sender = _currentUser.value?.username ?: "system"
        if (recipient == sender) return // No self-notifications
        dao.insertNotification(
            NotificationEntity(
                recipientUsername = recipient,
                senderUsername = sender,
                type = type,
                message = message,
                postId = postId
            )
        )
    }

    // --- Dummy/Seed Prep Populate on launch ---
    private suspend fun seedDatabaseIfEmpty() {
        val hasUsers = dao.searchUsers("").isNotEmpty()
        if (hasUsers) return

        // Create Seed profiles
        val official = UserEntity("airmint_official", "password", "Airmintrent Space", "Welcome to the future of social networking! AI Companion enabled. 🌬️🍃", "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=150&q=80", isPrivate = false)
        val tech = UserEntity("tech_master", "password", "Devon Stark", "Hardware hacker, Android pioneer, exploring neural boundaries.", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80", isPrivate = false)
        val wander = UserEntity("aurora_travel", "password", "Aurora Sky", "Lost in landscapes. Catching stories from mountains, trails & beaches. ⛰️🏔️", "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80", isPrivate = false)
        val pixel = UserEntity("pixel_chef", "password", "Chef Leo", "Cooking pixels and gourmet plates. Minimalist design lover.", "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=150&q=80", isPrivate = false)

        dao.insertUser(official)
        dao.insertUser(tech)
        dao.insertUser(wander)
        dao.insertUser(pixel)

        // Stories
        dao.insertStory(StoryEntity(authorUsername = "aurora_travel", authorName = "Aurora Sky", authorProfilePic = wander.profilePicUrl, mediaUrl = "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80"))
        dao.insertStory(StoryEntity(authorUsername = "pixel_chef", authorName = "Chef Leo", authorProfilePic = pixel.profilePicUrl, mediaUrl = "https://images.unsplash.com/photo-1488900128323-21503983a07e?auto=format&fit=crop&w=400&q=80"))
        dao.insertStory(StoryEntity(authorUsername = "tech_master", authorName = "Devon Stark", authorProfilePic = tech.profilePicUrl, mediaUrl = "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=400&q=80"))

        // Posts
        dao.insertPost(
            PostEntity(
                authorUsername = "airmint_official",
                authorName = "Airmintrent Space",
                authorProfilePic = official.profilePicUrl,
                content = "Airmintrent represents the fresh breeze in digital connection. Completely local fluid state, integrated live with Gemini AI for live caption ideas, seamless translation, and smart community safety protection. Type your first thought! #Airmintrent #FutureIsNear",
                mediaUrl = "https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=600&q=80",
                mediaType = "IMAGE",
                likesCount = 42,
                commentsCount = 2,
                location = "Cyber Hub"
            )
        )

        dao.insertPost(
            PostEntity(
                authorUsername = "aurora_travel",
                authorName = "Aurora Sky",
                authorProfilePic = wander.profilePicUrl,
                content = "Deep in the Swedish Lapland, watching the Aurora Borealis dance like green lanterns in the freezing sky. Zero signal, 100% connected. 🌌❄️",
                mediaUrl = "https://images.unsplash.com/photo-1521459467264-802e2ef3141f?auto=format&fit=crop&w=600&q=80",
                mediaType = "IMAGE",
                likesCount = 108,
                commentsCount = 1,
                location = "Abisko, Sweden"
            )
        )

        dao.insertPost(
            PostEntity(
                authorUsername = "tech_master",
                authorName = "Devon Stark",
                authorProfilePic = tech.profilePicUrl,
                content = "Refining deep Android EdgeToEdge architectures today. The viewport should flow under transparent system bars completely. Zero clunky grey cards allowed! #AndroidDev #ArtOfCode",
                mediaUrl = "",
                mediaType = "TEXT",
                likesCount = 31,
                commentsCount = 0,
                location = "Stark Labs"
            )
        )

        // Reels
        dao.insertReel(
            ReelEntity(
                authorUsername = "pixel_chef",
                authorName = "Chef Leo",
                authorProfilePic = pixel.profilePicUrl,
                content = "Artistic plating in 45 seconds: matcha white-chocolate lava cakes with frozen raspberry spheres. 🍵🧁 #DessertArt #PlatingSkills",
                videoUrl = "https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&w=400&q=80",
                audioTrack = "Original Audio - Chef Leo",
                likesCount = 380,
                commentsCount = 14
            )
        )

        dao.insertReel(
            ReelEntity(
                authorUsername = "tech_master",
                authorName = "Devon Stark",
                authorProfilePic = tech.profilePicUrl,
                content = "Testing my custom LED light grid arrays syncing to real-time ambient noise. Complete hardware synthesis loop in under 2ms! 🎧💡",
                videoUrl = "https://images.unsplash.com/photo-1563089145-599997674d42?auto=format&fit=crop&w=400&q=80",
                audioTrack = "Lo-Fi Beats for Coding",
                likesCount = 512,
                commentsCount = 24
            )
        )

        // Seed some Follows
        dao.insertFollow(FollowEntity(followerUsername = "tech_master", followingUsername = "airmint_official"))
        dao.insertFollow(FollowEntity(followerUsername = "aurora_travel", followingUsername = "airmint_official"))
    }
}

sealed class PostResult {
    data class Success(val postId: Int) : PostResult()
    data class SpamFlagged(val postId: Int) : PostResult()
    data class Error(val message: String) : PostResult()
}
