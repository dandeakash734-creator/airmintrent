package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.AppRepository
import com.example.ui.theme.*
import kotlinx.coroutines.launch

enum class AuthState {
    LOGIN, SIGNUP, FORGOT_PASSWORD
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    repository: AppRepository,
    onAuthSuccess: () -> Unit
) {
    var currentState by remember { mutableStateOf(AuthState.LOGIN) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var profilePic by remember { mutableStateOf("") }
    
    // Forgot Password Fields
    var forgotUsername by remember { mutableStateOf("") }
    var showResetSuccess by remember { mutableStateOf(false) }

    // Error / Loading Messages
    var errorMessage by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    // Avatar Selection options
    val mockAvatars = listOf(
        "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80",
        "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80",
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80",
        "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=150&q=80"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(BrandBg, BrandSurface)
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Airmintrent Logo Graphic Layer with dynamic circle and wind sparkles representation
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(colors = listOf(BrandMint.copy(alpha = 0.4f), Color.Transparent)))
                    .border(2.dp, BrandMint, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Air,
                    contentDescription = "Airmintrent Breeze",
                    tint = BrandMint,
                    modifier = Modifier.size(44.dp)
                )
                Icon(
                    imageVector = Icons.Default.WbSunny,
                    contentDescription = "Mint Glow",
                    tint = BrandCyan,
                    modifier = Modifier
                        .size(16.dp)
                        .align(Alignment.TopEnd)
                        .offset(x = (-4).dp, y = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Branding Title
            Text(
                text = "A I R M I N T R E N T",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 4.sp,
                    color = BrandMint
                )
            )
            Text(
                text = "Co-create on a fresh wavelength.",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = BrandGray,
                    letterSpacing = 0.5.sp
                ),
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            // Dynamic Form Box
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = BrandSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = when (currentState) {
                            AuthState.LOGIN -> "Welcome back"
                            AuthState.SIGNUP -> "Establish profile"
                            AuthState.FORGOT_PASSWORD -> "Reset profile key"
                        },
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        ),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    if (errorMessage.isNotEmpty()) {
                        Text(
                            text = errorMessage,
                            color = BrandRed,
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                    }

                    // Fields
                    when (currentState) {
                        AuthState.LOGIN -> {
                            OutlinedTextField(
                                value = username,
                                onValueChange = { username = it; errorMessage = "" },
                                label = { Text("Username") },
                                leadingIcon = { Icon(Icons.Default.AlternateEmail, contentDescription = null, tint = BrandMint) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BrandMint,
                                    unfocusedBorderColor = BrandSurfaceLighter,
                                    focusedLabelColor = BrandMint,
                                    unfocusedLabelColor = BrandGray,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = password,
                                onValueChange = { password = it; errorMessage = "" },
                                label = { Text("Secret Password") },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = BrandMint) },
                                visualTransformation = PasswordVisualTransformation(),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BrandMint,
                                    unfocusedBorderColor = BrandSurfaceLighter,
                                    focusedLabelColor = BrandMint,
                                    unfocusedLabelColor = BrandGray,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )
                        }

                        AuthState.SIGNUP -> {
                            OutlinedTextField(
                                value = fullName,
                                onValueChange = { fullName = it },
                                label = { Text("Full Name") },
                                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = BrandMint) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BrandMint,
                                    unfocusedBorderColor = BrandSurfaceLighter,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = username,
                                onValueChange = { username = it },
                                label = { Text("Username") },
                                leadingIcon = { Icon(Icons.Default.AlternateEmail, contentDescription = null, tint = BrandMint) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BrandMint,
                                    unfocusedBorderColor = BrandSurfaceLighter,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = password,
                                onValueChange = { password = it },
                                label = { Text("Password") },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = BrandMint) },
                                visualTransformation = PasswordVisualTransformation(),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BrandMint,
                                    unfocusedBorderColor = BrandSurfaceLighter,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = bio,
                                onValueChange = { bio = it },
                                label = { Text("Bio (Favorite Interests)") },
                                leadingIcon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = BrandMint) },
                                maxLines = 2,
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BrandMint,
                                    unfocusedBorderColor = BrandSurfaceLighter,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Avatar grid selector
                            Text(
                                text = "Select Identity Avatar",
                                style = MaterialTheme.typography.bodySmall.copy(color = BrandGray, fontWeight = FontWeight.SemiBold),
                                modifier = Modifier.align(Alignment.Start)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                mockAvatars.forEach { avatarUrl ->
                                    val isSelected = profilePic == avatarUrl
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .border(
                                                width = if (isSelected) 3.dp else 1.dp,
                                                color = if (isSelected) BrandMint else BrandSurfaceLighter,
                                                shape = CircleShape
                                            )
                                            .clickable { profilePic = avatarUrl }
                                    ) {
                                        AsyncImage(
                                            model = avatarUrl,
                                            contentDescription = "Avatar Options",
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }
                            }
                        }

                        AuthState.FORGOT_PASSWORD -> {
                            if (!showResetSuccess) {
                                OutlinedTextField(
                                    value = forgotUsername,
                                    onValueChange = { forgotUsername = it },
                                    label = { Text("Enter account Username") },
                                    leadingIcon = { Icon(Icons.Default.AlternateEmail, contentDescription = null, tint = BrandMint) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = BrandMint,
                                        unfocusedBorderColor = BrandSurfaceLighter,
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    )
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(BrandMuteBg, RoundedCornerShape(12.dp))
                                        .padding(12.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BrandMint, modifier = Modifier.size(36.dp))
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "A secure reset token has been simulated to your backup contact. Under community codes, you can sign in using: 'password'.",
                                            style = MaterialTheme.typography.bodySmall.copy(color = BrandOffWhite),
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    if (isLoading) {
                        CircularProgressIndicator(color = BrandMint)
                    } else {
                        Button(
                            onClick = {
                                when (currentState) {
                                    AuthState.LOGIN -> {
                                        if (username.isEmpty() || password.isEmpty()) {
                                            errorMessage = "Please enter login key parameters"
                                            return@Button
                                        }
                                        isLoading = true
                                        coroutineScope.launch {
                                            val ok = repository.login(username, password)
                                            isLoading = false
                                            if (ok) {
                                                onAuthSuccess()
                                            } else {
                                                errorMessage = "Incorrect parameters or banned account profile!"
                                            }
                                        }
                                    }
                                    AuthState.SIGNUP -> {
                                        if (username.isEmpty() || password.isEmpty() || fullName.isEmpty()) {
                                            errorMessage = "Fields with * are mandatory to establish profile"
                                            return@Button
                                        }
                                        isLoading = true
                                        coroutineScope.launch {
                                            val ok = repository.register(username, password, fullName, bio, profilePic)
                                            isLoading = false
                                            if (ok) {
                                                onAuthSuccess()
                                            } else {
                                                errorMessage = "Username belongs to another identity profile!"
                                            }
                                        }
                                    }
                                    AuthState.FORGOT_PASSWORD -> {
                                        if (!showResetSuccess) {
                                            if (forgotUsername.isEmpty()) {
                                                errorMessage = "What is your username?"
                                                return@Button
                                            }
                                            showResetSuccess = true
                                        } else {
                                            currentState = AuthState.LOGIN
                                            showResetSuccess = false
                                        }
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = when (currentState) {
                                    AuthState.LOGIN -> "Connect & Enter"
                                    AuthState.SIGNUP -> "Register New Identity"
                                    AuthState.FORGOT_PASSWORD -> if (!showResetSuccess) "Dispatch Reset Token" else "Back to Login"
                                },
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Secondary helper text
                    if (currentState == AuthState.LOGIN) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Create profile",
                                color = BrandCyan,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                modifier = Modifier.clickable {
                                    currentState = AuthState.SIGNUP
                                    errorMessage = ""
                                }
                            )
                            Text(
                                text = "Forgot keys?",
                                color = BrandGray,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.clickable {
                                    currentState = AuthState.FORGOT_PASSWORD
                                    errorMessage = ""
                                }
                            )
                        }
                    } else if (currentState == AuthState.SIGNUP) {
                        Text(
                            text = "Already registered? Login",
                            color = BrandCyan,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                            modifier = Modifier.clickable {
                                currentState = AuthState.LOGIN
                                errorMessage = ""
                            }
                        )
                    } else {
                        // Forgot Password Back options
                        if (!showResetSuccess) {
                            Text(
                                text = "Return to login screen",
                                color = BrandCyan,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                modifier = Modifier.clickable {
                                    currentState = AuthState.LOGIN
                                    errorMessage = ""
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            // Quick-Login Help Banner for easier testing in the Emulator
            Card(
                colors = CardDefaults.cardColors(containerColor = BrandSurface.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "⚡ QUICK DEV SEED LOGINS",
                        style = MaterialTheme.typography.labelSmall.copy(color = BrandMint, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Username: tech_master  |  Password: password",
                        style = MaterialTheme.typography.bodySmall.copy(color = BrandOffWhite, fontSize = 11.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                    )
                }
            }
        }
    }
}
