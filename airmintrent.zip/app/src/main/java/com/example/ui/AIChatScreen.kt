package com.example.ui

import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppRepository
import com.example.data.GeminiService
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import androidx.compose.foundation.shape.CircleShape
import coil.compose.AsyncImage
import java.util.Locale

data class ChatMessage(
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AIChatScreen(
    repository: AppRepository,
    onBack: () -> Unit
) {
    var messages by remember { mutableStateOf(listOf(
        ChatMessage("Welcome to Airmintrent AI Assistant! 🌬️🍃\n\nI can write captions, plan posts, translate comments, recommend circles, or just chat. Ask me anything!", false)
    )) }
    var prompt by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    // Tab state for specific tools
    var selectedToolTab by remember { mutableStateOf(0) } // 0: Chat, 1: Caption Generator, 2: Post Writer, 3: Translator, 4: Recs

    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    val currentUser by repository.currentUser.collectAsState()

    // Android TextToSpeech Setup
    var ttsInstance by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsInitialized by remember { mutableStateOf(false) }

    DisposableEffect(context) {
        val tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsInitialized = true
                Log.d("VoiceAI", "TTS Initialized successfully.")
            } else {
                Log.e("VoiceAI", "Failed to initialize TTS engine status = $status")
            }
        }
        tts.language = Locale.US
        ttsInstance = tts

        onDispose {
            tts.stop()
            tts.shutdown()
        }
    }

    fun speakLarge(text: String) {
        if (!ttsInitialized || ttsInstance == null) {
            Toast.makeText(context, "Voice synthesizer loading...", Toast.LENGTH_SHORT).show()
            return
        }
        // Speak out loud!
        ttsInstance?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "AirmintTTS")
        Toast.makeText(context, "🔊 Speaking AI Response...", Toast.LENGTH_SHORT).show()
    }

    // Welcoming popup trigger
    LaunchedEffect(currentUser) {
        val name = currentUser?.fullName ?: ""
        if (name.isNotEmpty()) {
            isLoading = true
            val welcomeText = GeminiService.welcomeUser(name)
            messages = messages + ChatMessage(welcomeText, false)
            isLoading = false
            // Autoplay the welcome message to surprise users!
            speakLarge(welcomeText)
        }
    }

    // Specific AI tools state
    var captionImageSubject by remember { mutableStateOf("") }
    var generatedCaptionResult by remember { mutableStateOf("") }

    // AI Hashtags state
    var hashtagsTopic by remember { mutableStateOf("") }
    var generatedHashtagsResult by remember { mutableStateOf("") }

    // AI Photo Creative Studio states
    val photoPresets = listOf(
        "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80", // Mountain Sunset
        "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=400&q=80", // Cybersecurity Neon Grid
        "https://images.unsplash.com/photo-1488900128323-21503983a07e?auto=format&fit=crop&w=400&q=80"  // Culinary Sweets
    )
    var selectedPhotoPresetIndex by remember { mutableStateOf(0) }
    var customPhotoUrl by remember { mutableStateOf("") }
    val activePhotoUrl = if (customPhotoUrl.isBlank()) photoPresets[selectedPhotoPresetIndex] else customPhotoUrl

    var selectedPhotoSubToolIndex by remember { mutableStateOf(0) } // 0: AI Photo Edit, 1: AI Background Remove, 2: AI Image Enhance
    var photoEditPromptText by remember { mutableStateOf("") }
    var photoEditResult by remember { mutableStateOf("") }
    var photoEditTintVaporwave by remember { mutableStateOf(false) }

    var isBackgroundRemoved by remember { mutableStateOf(false) }
    var backgroundRemoveResult by remember { mutableStateOf("") }

    var selectedEnhanceTier by remember { mutableStateOf("4x Ultra High-Res Upscale") }
    var isEnhancedApplied by remember { mutableStateOf(false) }
    var enhanceResult by remember { mutableStateOf("") }

    // AI Video Suite states
    val videoPresets = listOf(
        "https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&w=400&q=80", // Cozy Fireplace
        "https://images.unsplash.com/photo-1563089145-599997674d42?auto=format&fit=crop&w=400&q=80"  // Neon Nightwalk
    )
    var selectedVideoPresetIndex by remember { mutableStateOf(0) }
    var videoEditPromptText by remember { mutableStateOf("") }
    var videoEffectCinemaLUT by remember { mutableStateOf(true) }
    var videoEffectSlowMo by remember { mutableStateOf(false) }
    var videoEffectSynthBeats by remember { mutableStateOf(true) }
    var videoEditResult by remember { mutableStateOf("") }

    var postTopic by remember { mutableStateOf("") }
    var generatedPostResult by remember { mutableStateOf("") }

    var translationSource by remember { mutableStateOf("") }
    var translationTargetLang by remember { mutableStateOf("Spanish") }
    var generatedTranslationResult by remember { mutableStateOf("") }

    var recommendInterests by remember { mutableStateOf("") }
    var generatedRecsResult by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Airmintrent AI Studio", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = BrandMint)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = BrandMint)
                    }
                },
                actions = {
                    IconButton(onClick = { speakLarge("Airmintrent Voice synth module active. Click any speech bubble speakers to play the text back.") }) {
                        Icon(Icons.Default.VolumeUp, contentDescription = "TTS Help", tint = BrandMint)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BrandBg)
            )
        },
        containerColor = BrandBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Horizontal Scrollable Row of AI Modes
            ScrollableTabRow(
                selectedTabIndex = selectedToolTab,
                containerColor = BrandSurface,
                contentColor = BrandMint,
                edgePadding = 12.dp
            ) {
                Tab(selected = selectedToolTab == 0, onClick = { selectedToolTab = 0 }) {
                    Box(modifier = Modifier.padding(12.dp)) { Text("AI Assistant") }
                }
                Tab(selected = selectedToolTab == 1, onClick = { selectedToolTab = 1 }) {
                    Box(modifier = Modifier.padding(12.dp)) { Text("Caption & Tags") }
                }
                Tab(selected = selectedToolTab == 2, onClick = { selectedToolTab = 2 }) {
                    Box(modifier = Modifier.padding(12.dp)) { Text("Photo Studio") }
                }
                Tab(selected = selectedToolTab == 3, onClick = { selectedToolTab = 3 }) {
                    Box(modifier = Modifier.padding(12.dp)) { Text("Video Suite") }
                }
                Tab(selected = selectedToolTab == 4, onClick = { selectedToolTab = 4 }) {
                    Box(modifier = Modifier.padding(12.dp)) { Text("Post Writer") }
                }
                Tab(selected = selectedToolTab == 5, onClick = { selectedToolTab = 5 }) {
                    Box(modifier = Modifier.padding(12.dp)) { Text("Live Translate") }
                }
                Tab(selected = selectedToolTab == 6, onClick = { selectedToolTab = 6 }) {
                    Box(modifier = Modifier.padding(12.dp)) { Text("Recommendations") }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
                    .padding(16.dp)
            ) {
                when (selectedToolTab) {
                    0 -> {
                        // General Assistant Chat Log
                        Column(modifier = Modifier.fillMaxSize()) {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(messages) { msg ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = if (msg.isUser) Arrangement.End else Arrangement.Start,
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        if (!msg.isUser) {
                                            Icon(
                                                Icons.Default.AutoAwesome,
                                                contentDescription = "AI",
                                                tint = BrandMint,
                                                modifier = Modifier
                                                    .size(24.dp)
                                                    .padding(top = 4.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                        }

                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth(0.85f)
                                                .background(
                                                    color = if (msg.isUser) BrandSurfaceLighter else BrandSurface,
                                                    shape = RoundedCornerShape(
                                                        topStart = 16.dp,
                                                        topEnd = 16.dp,
                                                        bottomStart = if (msg.isUser) 16.dp else 0.dp,
                                                        bottomEnd = if (msg.isUser) 0.dp else 16.dp
                                                    )
                                                )
                                                .border(
                                                    1.dp,
                                                    if (msg.isUser) Color.Transparent else BrandMuteBg,
                                                    RoundedCornerShape(
                                                        topStart = 16.dp,
                                                        topEnd = 16.dp,
                                                        bottomStart = if (msg.isUser) 16.dp else 0.dp,
                                                        bottomEnd = if (msg.isUser) 0.dp else 16.dp
                                                    )
                                                )
                                                .padding(12.dp)
                                        ) {
                                            Text(
                                                text = msg.text,
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    color = BrandOffWhite,
                                                    lineHeight = 20.sp
                                                )
                                            )
                                            
                                            // Speak and play AI message triggers
                                            if (!msg.isUser) {
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Row(
                                                    modifier = Modifier
                                                        .align(Alignment.End)
                                                        .clickable { speakLarge(msg.text) },
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(
                                                        Icons.Default.VolumeUp,
                                                        contentDescription = "Speak Aloud",
                                                        tint = BrandMint,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        "Play Voice Responses",
                                                        style = MaterialTheme.typography.labelSmall.copy(color = BrandMint, fontSize = 10.sp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                if (isLoading) {
                                    item {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = BrandMint)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Airmint AI connection spinning...", style = MaterialTheme.typography.bodySmall.copy(color = BrandGray))
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Send Prompt Row
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = prompt,
                                    onValueChange = { prompt = it },
                                    placeholder = { Text("Compose assistant prompt...") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = BrandMint,
                                        unfocusedBorderColor = BrandSurfaceLighter,
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                IconButton(
                                    onClick = {
                                        if (prompt.trim().isEmpty()) return@IconButton
                                        val uPrompt = prompt
                                        messages = messages + ChatMessage(uPrompt, true)
                                        prompt = ""
                                        isLoading = true
                                        coroutineScope.launch {
                                            val response = GeminiService.askCompanion(uPrompt, messages.map { "${if (it.isUser) "User" else "AI"}: ${it.text}" })
                                            messages = messages + ChatMessage(response, false)
                                            isLoading = false
                                            // Play aloud immediately
                                            speakLarge(response)
                                        }
                                    },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .background(BrandMint, RoundedCornerShape(12.dp))
                                ) {
                                    Icon(Icons.Default.Send, contentDescription = "Send", tint = BrandBg)
                                }
                            }
                        }
                    }

                    1 -> {
                        // Caption & Tags
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BrandSurface),
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.ClosedCaption, contentDescription = null, tint = BrandMint)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("AI Caption Generator", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                                        }
                                        Text("Describe the activity, scenery, or mood of your feed post, story, or video reel to generate high-conversion captions.", fontSize = 11.sp, color = BrandGray)
                                        OutlinedTextField(
                                            value = captionImageSubject,
                                            onValueChange = { captionImageSubject = it },
                                            placeholder = { Text("e.g. 'Cozy evening with sunset light leaking through high pines'", color = Color.Gray) },
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                                        )
                                        Button(
                                            onClick = {
                                                if (captionImageSubject.isEmpty()) return@Button
                                                isLoading = true
                                                coroutineScope.launch {
                                                    generatedCaptionResult = GeminiService.generateCaption(captionImageSubject)
                                                    isLoading = false
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg)
                                        ) {
                                            Text("Synthesize Custom Caption")
                                        }

                                        if (isLoading && generatedCaptionResult.isEmpty()) {
                                            CircularProgressIndicator(color = BrandMint, modifier = Modifier.align(Alignment.CenterHorizontally))
                                        }

                                        if (generatedCaptionResult.isNotEmpty()) {
                                            GeneratedOutcomeCard(result = generatedCaptionResult, onSpeak = { speakLarge(generatedCaptionResult) })
                                        }
                                    }
                                }
                            }

                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BrandSurface),
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Sell, contentDescription = null, tint = BrandCyan)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("AI Hashtag Generator", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                                        }
                                        Text("Extract highly popular keywords and brand hashtags optimized for the Airmintrent and wider feed search indexing.", fontSize = 11.sp, color = BrandGray)
                                        OutlinedTextField(
                                            value = hashtagsTopic,
                                            onValueChange = { hashtagsTopic = it },
                                            placeholder = { Text("e.g. 'Tech hacking, cyberpunk neon keyboard setup'", color = Color.Gray) },
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandCyan, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                                        )
                                        Button(
                                            onClick = {
                                                if (hashtagsTopic.isEmpty()) return@Button
                                                isLoading = true
                                                coroutineScope.launch {
                                                    generatedHashtagsResult = GeminiService.generateHashtags(hashtagsTopic)
                                                    isLoading = false
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = ButtonDefaults.buttonColors(containerColor = BrandCyan, contentColor = BrandBg)
                                        ) {
                                            Text("Generate Trending Tags")
                                        }

                                        if (isLoading && generatedHashtagsResult.isEmpty()) {
                                            CircularProgressIndicator(color = BrandCyan, modifier = Modifier.align(Alignment.CenterHorizontally))
                                        }

                                        if (generatedHashtagsResult.isNotEmpty()) {
                                            Card(
                                                colors = CardDefaults.cardColors(containerColor = BrandMuteBg),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    Text("AI Curated Hashtags:", style = MaterialTheme.typography.labelSmall.copy(color = BrandCyan, fontWeight = FontWeight.Bold))
                                                    Text(generatedHashtagsResult, style = MaterialTheme.typography.bodyMedium.copy(color = Color.White, letterSpacing = 0.5.sp))
                                                    Button(
                                                        onClick = {
                                                            val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                                            val clip = android.content.ClipData.newPlainText("Airmint AI Tags", generatedHashtagsResult)
                                                            clipboard.setPrimaryClip(clip)
                                                            Toast.makeText(context, "🍃 Copied trending hashtags!", Toast.LENGTH_SHORT).show()
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = BrandSurfaceLighter, contentColor = BrandCyan),
                                                        modifier = Modifier.align(Alignment.End)
                                                    ) {
                                                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(12.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("Copy Tags", fontSize = 11.sp)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        // Photo Studio
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BrandSurface),
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Text("Select Image to Process", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                                        
                                        // Presets
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            photoPresets.forEachIndexed { idx, url ->
                                                Box(
                                                    modifier = Modifier
                                                        .size(72.dp)
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .border(
                                                            width = if (selectedPhotoPresetIndex == idx && customPhotoUrl.isEmpty()) 3.dp else 1.dp,
                                                            color = if (selectedPhotoPresetIndex == idx && customPhotoUrl.isEmpty()) BrandMint else BrandSurfaceLighter,
                                                            shape = RoundedCornerShape(12.dp)
                                                        )
                                                        .clickable {
                                                            selectedPhotoPresetIndex = idx
                                                            customPhotoUrl = ""
                                                            // reset output views on image swap
                                                            photoEditResult = ""
                                                            isBackgroundRemoved = false
                                                            backgroundRemoveResult = ""
                                                            isEnhancedApplied = false
                                                            enhanceResult = ""
                                                        }
                                                ) {
                                                    AsyncImage(
                                                        model = url,
                                                        contentDescription = null,
                                                        modifier = Modifier.fillMaxSize(),
                                                        contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                                    )
                                                    Box(
                                                        modifier = Modifier
                                                            .fillMaxSize()
                                                            .background(Color.Black.copy(alpha = 0.15f))
                                                    )
                                                }
                                            }
                                        }

                                        Text("Or supply a custom remote photo link:", fontSize = 10.sp, color = BrandGray)
                                        OutlinedTextField(
                                            value = customPhotoUrl,
                                            onValueChange = { customPhotoUrl = it },
                                            placeholder = { Text("e.g. https://domain.com/photo.jpg", color = Color.Gray, fontSize = 11.sp) },
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                                        )

                                        // Image Interactive Box with visual modifications!
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(200.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(
                                                    if (isBackgroundRemoved) {
                                                        // Chess checkered pattern to visually demonstrate transparency!
                                                        Color.DarkGray
                                                    } else {
                                                        BrandSurfaceLighter
                                                    }
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (isBackgroundRemoved) {
                                                // Simulated checkered transparency background
                                                Column(modifier = Modifier.fillMaxSize().background(Color.Gray.copy(alpha = 0.25f))) {
                                                    // Renders transparent icon helper
                                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                                        Text("TRANSPARENT MATTE ACTIVE", style = MaterialTheme.typography.labelSmall.copy(color = BrandMint, fontWeight = FontWeight.Bold))
                                                    }
                                                }
                                            }

                                            AsyncImage(
                                                model = activePhotoUrl,
                                                contentDescription = "Selected Art Piece",
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .then(
                                                        if (isBackgroundRemoved) Modifier.padding(16.dp).clip(CircleShape) else Modifier
                                                    ),
                                                contentScale = if (isBackgroundRemoved) androidx.compose.ui.layout.ContentScale.Fit else androidx.compose.ui.layout.ContentScale.Crop
                                            )

                                            // Apply Color Tint simulation if vaporwave filter is active
                                            if (photoEditTintVaporwave) {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxSize()
                                                        .background(Color(0xFFE91E63).copy(alpha = 0.35f)) // Reddish Vaporwave Tint!
                                                )
                                                Box(modifier = Modifier.align(Alignment.TopEnd).padding(10.dp).background(BrandRed, RoundedCornerShape(8.dp)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                                                    Text("VAPORWAVE TINT ACTIVE", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                                }
                                            }

                                            // Apply crisp overlay comparison if enhanced is applied
                                            if (isEnhancedApplied) {
                                                // High contrast crisp overlay simulation
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxSize()
                                                        .border(4.dp, BrandMint, RoundedCornerShape(14.dp))
                                                )
                                                Box(modifier = Modifier.align(Alignment.BottomStart).padding(10.dp).background(BrandMint, RoundedCornerShape(8.dp)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                                                    Text("AI HDR ENHANCED 4K UPSEAL", fontSize = 9.sp, color = BrandBg, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }

                                        // Segment Tab selectors for Photo Tools
                                        TabRow(
                                            selectedTabIndex = selectedPhotoSubToolIndex,
                                            containerColor = BrandMuteBg,
                                            contentColor = BrandMint,
                                            modifier = Modifier.clip(RoundedCornerShape(10.dp))
                                        ) {
                                            Tab(selected = selectedPhotoSubToolIndex == 0, onClick = { selectedPhotoSubToolIndex = 0 }) {
                                                Box(modifier = Modifier.padding(10.dp)) { Text("AI Photo Edit", fontSize = 11.sp) }
                                            }
                                            Tab(selected = selectedPhotoSubToolIndex == 1, onClick = { selectedPhotoSubToolIndex = 1 }) {
                                                Box(modifier = Modifier.padding(10.dp)) { Text("Remove BG", fontSize = 11.sp) }
                                            }
                                            Tab(selected = selectedPhotoSubToolIndex == 2, onClick = { selectedPhotoSubToolIndex = 2 }) {
                                                Box(modifier = Modifier.padding(10.dp)) { Text("AI Enhance", fontSize = 11.sp) }
                                            }
                                        }

                                        // Active Subtool Panels
                                        when (selectedPhotoSubToolIndex) {
                                            0 -> {
                                                // AI Photo Edit
                                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                                    Text("Instruct how you want AI to edit this photography:", fontSize = 11.sp, color = BrandOffWhite)
                                                    OutlinedTextField(
                                                        value = photoEditPromptText,
                                                        onValueChange = { photoEditPromptText = it },
                                                        placeholder = { Text("e.g. 'Add deep moody contrast and vaporwave magenta tint'", color = Color.Gray, fontSize = 11.sp) },
                                                        modifier = Modifier.fillMaxWidth(),
                                                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                                                    )
                                                    
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Checkbox(
                                                            checked = photoEditTintVaporwave,
                                                            onCheckedChange = { photoEditTintVaporwave = it },
                                                            colors = CheckboxDefaults.colors(checkedColor = BrandMint)
                                                        )
                                                        Text("Simulate Ambient Vaporwave Warm Glow Overlay", color = Color.White, fontSize = 11.sp)
                                                    }

                                                    Button(
                                                        onClick = {
                                                            if (photoEditPromptText.isEmpty()) return@Button
                                                            isLoading = true
                                                            coroutineScope.launch {
                                                                photoEditResult = GeminiService.applyPhotoEdit(activePhotoUrl, photoEditPromptText)
                                                                if (photoEditPromptText.lowercase().contains("vapor") || photoEditPromptText.lowercase().contains("tint")) {
                                                                    photoEditTintVaporwave = true
                                                                }
                                                                isLoading = false
                                                            }
                                                        },
                                                        modifier = Modifier.fillMaxWidth(),
                                                        colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg)
                                                    ) {
                                                        Text("Re-Imagine with AI Photo Edit")
                                                    }

                                                    if (isLoading && photoEditResult.isEmpty()) {
                                                        CircularProgressIndicator(color = BrandMint, modifier = Modifier.align(Alignment.CenterHorizontally))
                                                    }

                                                    if (photoEditResult.isNotEmpty()) {
                                                        GeneratedOutcomeCard(result = photoEditResult, onSpeak = { speakLarge(photoEditResult) })
                                                    }
                                                }
                                            }
                                            1 -> {
                                                // Remove Background
                                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                                    Text("The neural network extracts the portrait subject, clearing color layers in the background.", fontSize = 11.sp, color = BrandGray)
                                                    
                                                    Button(
                                                        onClick = {
                                                            isLoading = true
                                                            coroutineScope.launch {
                                                                // Simulates scanning delay
                                                                backgroundRemoveResult = GeminiService.removeBackground(activePhotoUrl)
                                                                isBackgroundRemoved = true
                                                                isLoading = false
                                                            }
                                                        },
                                                        modifier = Modifier.fillMaxWidth(),
                                                        colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg)
                                                    ) {
                                                        Text("Perform Background Removal")
                                                    }

                                                    if (isLoading) {
                                                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                                                            LinearProgressIndicator(color = BrandMint, modifier = Modifier.fillMaxWidth())
                                                            Spacer(modifier = Modifier.height(6.dp))
                                                            Text("Analyzing edges & extracting alpha channels...", fontSize = 10.sp, color = BrandMint)
                                                        }
                                                    }

                                                    if (backgroundRemoveResult.isNotEmpty()) {
                                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                            Button(
                                                                onClick = {
                                                                    isBackgroundRemoved = false
                                                                    backgroundRemoveResult = ""
                                                                },
                                                                colors = ButtonDefaults.buttonColors(containerColor = BrandSurfaceLighter, contentColor = Color.White)
                                                            ) {
                                                                Text("Reset BG", fontSize = 11.sp)
                                                            }
                                                        }
                                                        GeneratedOutcomeCard(result = backgroundRemoveResult, onSpeak = { speakLarge(backgroundRemoveResult) })
                                                    }
                                                }
                                            }
                                            2 -> {
                                                // AI Image Enhance
                                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                                    Text("Select Enhancement Quality Level:", fontSize = 11.sp, color = BrandOffWhite)
                                                    
                                                    val tiers = listOf("4x Ultra High-Res Upscale", "AI Denoise & Clear", "HDR Vivid Contrast")
                                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                                        tiers.forEach { tier ->
                                                            Box(
                                                                modifier = Modifier
                                                                    .weight(1f)
                                                                    .background(if (selectedEnhanceTier == tier) BrandMint else BrandSurfaceLighter, RoundedCornerShape(8.dp))
                                                                    .clickable { selectedEnhanceTier = tier }
                                                                    .padding(vertical = 8.dp, horizontal = 4.dp),
                                                                contentAlignment = Alignment.Center
                                                            ) {
                                                                Text(tier, color = if (selectedEnhanceTier == tier) BrandSurface else Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                                                            }
                                                        }
                                                    }

                                                    Button(
                                                        onClick = {
                                                            isLoading = true
                                                            coroutineScope.launch {
                                                                enhanceResult = GeminiService.enhanceImage(activePhotoUrl, selectedEnhanceTier)
                                                                isEnhancedApplied = true
                                                                isLoading = false
                                                            }
                                                        },
                                                        modifier = Modifier.fillMaxWidth(),
                                                        colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg)
                                                    ) {
                                                        Text("Apply Image Enhancement")
                                                    }

                                                    if (isLoading && enhanceResult.isEmpty()) {
                                                        CircularProgressIndicator(color = BrandMint, modifier = Modifier.align(Alignment.CenterHorizontally))
                                                    }

                                                    if (enhanceResult.isNotEmpty()) {
                                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                            Button(
                                                                onClick = {
                                                                    isEnhancedApplied = false
                                                                    enhanceResult = ""
                                                                },
                                                                colors = ButtonDefaults.buttonColors(containerColor = BrandSurfaceLighter, contentColor = Color.White)
                                                            ) {
                                                                Text("Reset Enhance", fontSize = 11.sp)
                                                            }
                                                        }
                                                        GeneratedOutcomeCard(result = enhanceResult, onSpeak = { speakLarge(enhanceResult) })
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    3 -> {
                        // Video Suite
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BrandSurface),
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Text("AI Video Editing Studio", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                                        Text("Render elegant TikTok or Reels style clips with synchronized audio, voiceover scripts, and Kodak color grading.", fontSize = 11.sp, color = BrandGray)

                                        // Select Video Preset
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            videoPresets.forEachIndexed { idx, url ->
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(100.dp)
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .border(
                                                            width = if (selectedVideoPresetIndex == idx) 3.dp else 1.dp,
                                                            color = if (selectedVideoPresetIndex == idx) BrandMint else BrandSurfaceLighter,
                                                            shape = RoundedCornerShape(12.dp)
                                                        )
                                                        .clickable {
                                                            selectedVideoPresetIndex = idx
                                                            videoEditResult = ""
                                                        }
                                                ) {
                                                    AsyncImage(
                                                        model = url,
                                                        contentDescription = null,
                                                        modifier = Modifier.fillMaxSize(),
                                                        contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                                    )
                                                    Box(
                                                        modifier = Modifier
                                                            .fillMaxSize()
                                                            .background(Color.Black.copy(alpha = 0.3f)),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(Icons.Filled.PlayArrow, contentDescription = "Play Icon Preset", tint = BrandMint, modifier = Modifier.size(32.dp))
                                                    }
                                                }
                                            }
                                        }

                                        HorizontalDivider(color = BrandSurfaceLighter)

                                        Text("AI Processing Options:", style = MaterialTheme.typography.bodyMedium.copy(color = Color.White, fontWeight = FontWeight.Bold))
                                        
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Checkbox(checked = videoEffectCinemaLUT, onCheckedChange = { videoEffectCinemaLUT = it }, colors = CheckboxDefaults.colors(checkedColor = BrandMint))
                                            Text("Apply Cinema-Grade Warm Kodak LUT color grading", fontSize = 11.sp, color = Color.White)
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Checkbox(checked = videoEffectSlowMo, onCheckedChange = { videoEffectSlowMo = it }, colors = CheckboxDefaults.colors(checkedColor = BrandMint))
                                            Text("Smooth 120fps Slow-Motion Retime mapping (0.5x)", fontSize = 11.sp, color = Color.White)
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Checkbox(checked = videoEffectSynthBeats, onCheckedChange = { videoEffectSynthBeats = it }, colors = CheckboxDefaults.colors(checkedColor = BrandMint))
                                            Text("Overlay sync background instrumental techno & synth waves", fontSize = 11.sp, color = Color.White)
                                        }

                                        Text("Custom Voiceover Script or Cut Direction:", fontSize = 11.sp, color = BrandOffWhite)
                                        OutlinedTextField(
                                            value = videoEditPromptText,
                                            onValueChange = { videoEditPromptText = it },
                                            placeholder = { Text("e.g. 'Read: Exploring new digital frontiers. Cut fast on bass peaks.'", color = Color.Gray, fontSize = 11.sp) },
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                                        )

                                        Button(
                                            onClick = {
                                                isLoading = true
                                                val opts = buildString {
                                                    if (videoEffectCinemaLUT) append("CinemaLUT;")
                                                    if (videoEffectSlowMo) append("SlowMotion;")
                                                    if (videoEffectSynthBeats) append("BackgroundSynthWaves;")
                                                }
                                                coroutineScope.launch {
                                                    videoEditResult = GeminiService.applyVideoEdit(videoPresets[selectedVideoPresetIndex], videoEditPromptText.ifBlank { "Unbound AI edit" }, opts)
                                                    isLoading = false
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg)
                                        ) {
                                            Text("Compile & Render AI Video Edit")
                                        }

                                        if (isLoading) {
                                            Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                                LinearProgressIndicator(color = BrandMint, modifier = Modifier.fillMaxWidth())
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Text("Applying color grading... Synced beats... Rendering MP4 stream...", fontSize = 10.sp, color = BrandMint)
                                            }
                                        }

                                        if (videoEditResult.isNotEmpty()) {
                                            GeneratedOutcomeCard(result = videoEditResult, onSpeak = { speakLarge(videoEditResult) })
                                        }
                                    }
                                }
                            }
                        }
                    }

                    4 -> {
                        // AI Post Writer
                        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            Text("AI Post Writer", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                            OutlinedTextField(
                                value = postTopic,
                                onValueChange = { postTopic = it },
                                placeholder = { Text("Provide post topic/draft context... e.g. 'Importance of quiet digital breaks'") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                            )
                            Button(
                                onClick = {
                                    if (postTopic.isEmpty()) return@Button
                                    isLoading = true
                                    coroutineScope.launch {
                                        generatedPostResult = GeminiService.writePost(postTopic)
                                        isLoading = false
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg)
                            ) {
                                Text("Synthesize Microblog Post")
                            }

                            if (isLoading) {
                                CircularProgressIndicator(color = BrandMint, modifier = Modifier.align(Alignment.CenterHorizontally))
                            }

                            if (generatedPostResult.isNotEmpty()) {
                                GeneratedOutcomeCard(result = generatedPostResult, onSpeak = { speakLarge(generatedPostResult) })
                            }
                        }
                    }

                    5 -> {
                        // Dynamic Translate Action
                        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            Text("AI Transliteration & Translation", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                            OutlinedTextField(
                                value = translationSource,
                                onValueChange = { translationSource = it },
                                placeholder = { Text("What text are we translating today?") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                            )
                            OutlinedTextField(
                                value = translationTargetLang,
                                onValueChange = { translationTargetLang = it },
                                label = { Text("Target Language (default Spanish)") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                            )
                            Button(
                                onClick = {
                                    if (translationSource.isEmpty()) return@Button
                                    isLoading = true
                                    coroutineScope.launch {
                                        generatedTranslationResult = GeminiService.translateComment(translationSource, translationTargetLang)
                                        isLoading = false
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg)
                            ) {
                                Text("Translate Instantly")
                            }

                            if (isLoading) {
                                CircularProgressIndicator(color = BrandMint, modifier = Modifier.align(Alignment.CenterHorizontally))
                            }

                            if (generatedTranslationResult.isNotEmpty()) {
                                GeneratedOutcomeCard(result = generatedTranslationResult, onSpeak = { speakLarge(generatedTranslationResult) })
                            }
                        }
                    }

                    6 -> {
                        // Content Recommendations
                        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            Text("Smart Content Recommendation", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                            OutlinedTextField(
                                value = recommendInterests,
                                onValueChange = { recommendInterests = it },
                                placeholder = { Text("Input 2-3 of your personal hobbies/interests... e.g. 'Coding, photography'") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                            )
                            Button(
                                onClick = {
                                    if (recommendInterests.isEmpty()) return@Button
                                    isLoading = true
                                    coroutineScope.launch {
                                        generatedRecsResult = GeminiService.getRecommendations(recommendInterests)
                                        isLoading = false
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg)
                            ) {
                                Text("Generate Recommendations")
                            }

                            if (isLoading) {
                                CircularProgressIndicator(color = BrandMint, modifier = Modifier.align(Alignment.CenterHorizontally))
                            }

                            if (generatedRecsResult.isNotEmpty()) {
                                GeneratedOutcomeCard(result = generatedRecsResult, onSpeak = { speakLarge(generatedRecsResult) })
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GeneratedOutcomeCard(result: String, onSpeak: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = BrandSurface),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Airmintrent AI Result:", style = MaterialTheme.typography.labelSmall.copy(color = BrandMint, fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(8.dp))
            Text(result, style = MaterialTheme.typography.bodyMedium.copy(color = Color.White, lineHeight = 20.sp))
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSpeak() },
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.VolumeUp, contentDescription = "Play", tint = BrandMint, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Synthesize Audio Voice", style = MaterialTheme.typography.bodySmall.copy(color = BrandMint, fontWeight = FontWeight.Bold))
            }
        }
    }
}
