package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = BrandMint,
    secondary = BrandCyan,
    tertiary = BrandGray,
    background = BrandBg,
    surface = BrandSurface,
    onPrimary = BrandBg,
    onSecondary = BrandBg,
    onTertiary = Color.White,
    onBackground = BrandOffWhite,
    onSurface = BrandOffWhite,
    error = BrandRed
)

// Fallback light theme, but default is dark since user specified dark theme
private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF00B08B),
    secondary = Color(0xFF0091A8),
    tertiary = BrandGray,
    background = Color(0xFFF9FAFB),
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = Color(0xFF111827),
    onSurface = Color(0xFF111827),
    error = BrandRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force dark theme by default as explicitly requested!
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
