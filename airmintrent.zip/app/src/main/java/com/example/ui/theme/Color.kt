package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Dark Theme Palette
val BrandBg = Color(0xFF121316)       // Deep Charcoal Black
val BrandSurface = Color(0xFF1C1E21)  // Slate Card Background
val BrandSurfaceLighter = Color(0xFF2D2F31) // Highlight surface card / borders
val BrandMint = Color(0xFFD1E8E2)     // Elegant Soft Mint Green
val BrandCyan = Color(0xFFA8D5BA)     // Cool Sage/Mint Accent
val BrandOffWhite = Color(0xFFE2E2E6) // Light Silver Gray
val BrandGray = Color(0xFFC4C6CF)     // Cool Gray
val BrandRed = Color(0xFFF28B82)      // Warm Soft Rose Pink
val BrandMuteBg = Color(0xFF2D2F31)   // Muted Background card space
