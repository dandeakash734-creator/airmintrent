package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppRepository
import com.example.data.ReportEntity
import com.example.data.UserEntity
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    repository: AppRepository,
    onBack: () -> Unit
) {
    var adminTabState by remember { mutableStateOf(0) } // 0: Analytics, 1: Reports Review, 2: User management
    val coroutineScope = rememberCoroutineScope()

    // Query live reports
    val reportsList by repository.dao.getAllReportsFlow().collectAsState(initial = emptyList())
    // Query live users list
    val usersList by repository.dao.getAllUsersFlow().collectAsState(initial = emptyList())

    // Metrics calculation
    val allPosts by repository.dao.getAllPostsFlow().collectAsState(initial = emptyList())
    val allReels by repository.dao.getAllReelsFlow().collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Airmintrent Admin Panel", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = BrandMint)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = BrandMint)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BrandSurface)
            )
        },
        containerColor = BrandBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // TabRow selector for Admin Actions
            TabRow(
                selectedTabIndex = adminTabState,
                containerColor = BrandSurface,
                contentColor = BrandMint
            ) {
                Tab(selected = adminTabState == 0, onClick = { adminTabState = 0 }) {
                    Box(modifier = Modifier.padding(12.dp)) { Text("Analytics") }
                }
                Tab(selected = adminTabState == 1, onClick = { adminTabState = 1 }) {
                    Box(modifier = Modifier.padding(12.dp)) { Text("Review Reports (${reportsList.filter { it.status == "PENDING" }.size})") }
                }
                Tab(selected = adminTabState == 2, onClick = { adminTabState = 2 }) {
                    Box(modifier = Modifier.padding(12.dp)) { Text("Users Control") }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                when (adminTabState) {
                    0 -> {
                        // Analytics dashboard Metrics
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            item {
                                Text("Platform Growth Stat Indicators", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = BrandMint))
                            }

                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    MetricCard(title = "Users", count = usersList.size.toString(), color = BrandMint, modifier = Modifier.weight(1f))
                                    MetricCard(title = "Total Posts", count = allPosts.size.toString(), color = BrandCyan, modifier = Modifier.weight(1f))
                                }
                            }

                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    MetricCard(title = "Total Reels", count = allReels.size.toString(), color = BrandMint, modifier = Modifier.weight(1f))
                                    MetricCard(title = "Filed Reports", count = reportsList.size.toString(), color = BrandRed, modifier = Modifier.weight(1f))
                                }
                            }

                            item {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("System Activity Monitor", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = BrandMint))
                            }

                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BrandSurface),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text("AI Content Moderation Shield Load", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, color = BrandOffWhite))
                                        Spacer(modifier = Modifier.height(12.dp))
                                        
                                        // Visual indicator bars representing analytics state
                                        StatRatioBar(label = "Spam Filter Success Rate", ratio = 0.98f, color = BrandMint)
                                        Spacer(modifier = Modifier.height(8.dp))
                                        StatRatioBar(label = "Banned Users of Total Ratio", ratio = (usersList.filter { it.isBanned }.size.toFloat() / usersList.size.toFloat().coerceAtLeast(1f)), color = BrandRed)
                                        Spacer(modifier = Modifier.height(8.dp))
                                        StatRatioBar(label = "Resolved Reports Rate", ratio = (reportsList.filter { it.status == "RESOLVED" }.size.toFloat() / reportsList.size.toFloat().coerceAtLeast(1f)), color = BrandCyan)
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        // Reports Review List view
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            if (reportsList.isEmpty()) {
                                item {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(40.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = BrandMint, modifier = Modifier.size(48.dp))
                                            Spacer(modifier = Modifier.height(12.dp))
                                            Text("All reports cleared! Creative space intact. ✨", style = MaterialTheme.typography.bodyMedium.copy(color = BrandGray), textAlign = TextAlign.Center)
                                        }
                                    }
                                }
                            } else {
                                items(reportsList) { report ->
                                    ReportReviewItem(
                                        report = report,
                                        onResolvePostReport = {
                                            // Handle post report action
                                            coroutineScope.launch {
                                                if (report.reportedType == "POST") {
                                                    repository.deletePostByAdmin(report.targetId.toIntOrNull() ?: 0)
                                                }
                                                repository.dao.updateReport(report.copy(status = "RESOLVED"))
                                            }
                                        },
                                        onResolveUserReport = {
                                            coroutineScope.launch {
                                                if (report.reportedType == "USER") {
                                                    repository.banUser(report.targetId)
                                                }
                                                repository.dao.updateReport(report.copy(status = "RESOLVED"))
                                            }
                                        },
                                        onIgnore = {
                                            coroutineScope.launch {
                                                repository.dao.updateReport(report.copy(status = "RESOLVED"))
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }

                    2 -> {
                        // User Management list
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(usersList) { u ->
                                UserControlRow(
                                    user = u,
                                    onBanToggle = {
                                        coroutineScope.launch {
                                            if (u.isBanned) {
                                                repository.unbanUser(u.username)
                                            } else {
                                                repository.banUser(u.username)
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(title: String, count: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = BrandSurface),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.bodySmall.copy(color = BrandGray))
            Spacer(modifier = Modifier.height(4.dp))
            Text(count, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black, color = color))
        }
    }
}

@Composable
fun StatRatioBar(label: String, ratio: Float, color: Color) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodySmall.copy(color = BrandGray))
            Text("${(ratio * 100).toInt()}%", style = MaterialTheme.typography.bodySmall.copy(color = color, fontWeight = FontWeight.Bold))
        }
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .background(BrandMuteBg, RoundedCornerShape(4.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(ratio.coerceIn(0f, 1f))
                    .fillMaxHeight()
                    .background(color, RoundedCornerShape(4.dp))
            )
        }
    }
}

@Composable
fun ReportReviewItem(
    report: ReportEntity,
    onResolvePostReport: () -> Unit,
    onResolveUserReport: () -> Unit,
    onIgnore: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = BrandSurface),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(if (report.status == "PENDING") BrandRed else BrandMint, RoundedCornerShape(4.dp))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Report type: ${report.reportedType}",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = BrandGray)
                    )
                }

                Text(
                    text = report.status,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (report.status == "PENDING") BrandRed else BrandMint
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text("Reporter: ${report.reporterUsername}", style = MaterialTheme.typography.bodySmall.copy(color = BrandOffWhite))
            Text("Reported target: @${report.targetId}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
            Text("Reason: \"${report.reason}\"", style = MaterialTheme.typography.bodySmall.copy(color = BrandGray))

            if (report.status == "PENDING") {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            if (report.reportedType == "POST") onResolvePostReport() else onResolveUserReport()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandRed, contentColor = Color.White),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text(if (report.reportedType == "POST") "Delete Post" else "Ban User", fontSize = 12.sp)
                    }

                    Button(
                        onClick = onIgnore,
                        colors = ButtonDefaults.buttonColors(containerColor = BrandSurfaceLighter, contentColor = BrandOffWhite),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("Ignore Report", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun UserControlRow(
    user: UserEntity,
    onBanToggle: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = BrandSurface),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(user.fullName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                Text("@${user.username}", style = MaterialTheme.typography.bodySmall.copy(color = BrandGray))
            }

            Button(
                onClick = onBanToggle,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (user.isBanned) BrandMint else BrandMuteBg,
                    contentColor = if (user.isBanned) BrandBg else BrandRed
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(text = if (user.isBanned) "Unban profile" else "Ban profile", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
