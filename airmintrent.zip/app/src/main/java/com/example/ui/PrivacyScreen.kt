package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppRepository
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyScreen(
    repository: AppRepository,
    onBack: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Safety Center (Blocks/Reports), 1: Guidelines, 2: Privacy Policy
    val coroutineScope = rememberCoroutineScope()
    val currentUser by repository.currentUser.collectAsState()

    // Retrieve live blocks list
    val blockedUsernames by remember(currentUser) { 
        repository.dao.getBlockedUsernamesFlow(currentUser?.username ?: "") 
    }.collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text("Safety & Trust Center", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = BrandMint))
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = BrandMint)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BrandBg)
            )
        },
        containerColor = BrandBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Tab Selector
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = BrandSurface,
                contentColor = BrandMint
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("User Safety", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Guidelines", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Privacy details", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)) }
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        // User Safety Center
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BrandSurfaceLighter.copy(alpha = 0.5f)),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Shield, contentDescription = "Shield", tint = BrandMint, modifier = Modifier.size(32.dp))
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text(
                                                text = "Airmintrent Shield Active",
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "Our neural algorithms continuously scan posts and direct messages for spam, fraud schemes, fake currency listings, and hostile behavioral traits to protect co-creators.",
                                            style = MaterialTheme.typography.bodySmall.copy(color = BrandGray)
                                        )
                                    }
                                }
                            }

                            item {
                                Text(
                                    text = "Your Block List (${blockedUsernames.size})",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White),
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            }

                            if (blockedUsernames.isEmpty()) {
                                item {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = BrandSurface),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(24.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Icon(Icons.Default.PeopleOutline, contentDescription = null, tint = BrandGray, modifier = Modifier.size(40.dp))
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text("No profile blocked by your account", style = MaterialTheme.typography.bodySmall.copy(color = BrandGray), textAlign = TextAlign.Center)
                                            }
                                        }
                                    }
                                }
                            } else {
                                items(blockedUsernames) { username ->
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = BrandSurface),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.AlternateEmail, contentDescription = null, tint = BrandMint, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(username, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                                            }
                                            Button(
                                                onClick = {
                                                    coroutineScope.launch {
                                                        repository.unblockUser(username)
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = BrandSurfaceLighter, contentColor = BrandMint),
                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                                modifier = Modifier.height(32.dp),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text("Unblock", fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                            }

                            // Fraud Reporting Tips
                            item {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Reporting Center Helpful Info",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White)
                                )
                            }
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BrandSurface)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text("⚠️ How to Report posts:", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = BrandCyan))
                                        Text("Simply tap the menu options inside any feed item and select 'Report'. A dynamic submission will be forwarded directly to the Admin reviews dashboard for swift ban/unban moderation review.", style = MaterialTheme.typography.bodySmall.copy(color = BrandGray))
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        // Community Guidelines
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            item {
                                Text(
                                    text = "Airmintrent Community Codes",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black, color = BrandMint)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "To guarantee organic connections and healthy wind circles, we require compliance with our code rules.",
                                    style = MaterialTheme.typography.bodySmall.copy(color = BrandGray)
                                )
                            }

                            item {
                                GuidelineItem(
                                    title = "1. Express Authentically",
                                    desc = "Co-creation requires honesty. Respect copyright. Do not impersonate public identities, trade credentials, or fake reports."
                                )
                            }
                            item {
                                GuidelineItem(
                                    title = "2. No Scamming or Spamming Schemes",
                                    desc = "We have zero tolerance for clickbait link redirects, false currency giveaways (free tokens, crypto, easy money traps), or spam post repeating."
                                )
                            }
                            item {
                                GuidelineItem(
                                    title = "3. Zero Slander/Harassment Policy",
                                    desc = "Airmintrent is structured as a premium creative environment. Do not engage in targeted pile-on attacks, cyber-bully tactics, or invasive slanders."
                                )
                            }
                            item {
                                GuidelineItem(
                                    title = "4. Clear Metadata & Identity",
                                    desc = "Keep profile descriptions, bios, and stories aligned with honest creative expression to build high trust levels across the platform."
                                )
                            }
                        }
                    }

                    2 -> {
                        // Privacy Policy
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            item {
                                Text(
                                    text = "Privacy Rights & Data Control",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black, color = BrandCyan)
                                )
                            }
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BrandSurface)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text(
                                            text = "Airmintrent is designed from the core on a trust model. Your data, posts, reels, stories, direct letters, and voice message binaries are stored in highly secure, isolated database layers.",
                                            style = MaterialTheme.typography.bodyMedium.copy(color = BrandOffWhite, lineHeight = 20.sp)
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = "Key Rights:\n• Toggle Private/Public profiling status at any moment in account settings.\n• Complete control over profile deletion or block lists.\n• Zero secondary data tracking or marketing sales pipelines.\n• Local-first memory caching protocols for fast response speeds.",
                                            style = MaterialTheme.typography.bodySmall.copy(color = BrandGray, lineHeight = 18.sp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GuidelineItem(title: String, desc: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = BrandSurface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = Color.White))
            Spacer(modifier = Modifier.height(4.dp))
            Text(desc, style = MaterialTheme.typography.bodySmall.copy(color = BrandGray))
        }
    }
}
