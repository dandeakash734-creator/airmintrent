package com.example.ui

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainLayout(
    repository: AppRepository,
    onNavigateToAI: () -> Unit,
    onNavigateToSafety: () -> Unit,
    onNavigateToAdmin: () -> Unit,
    onLogout: () -> Unit
) {
    var activeTab by remember { mutableStateOf(0) } // 0: Feed, 1: Explore, 2: Reels, 3: Direct Messages, 4: Profile
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    val currentUser by repository.currentUser.collectAsState()

    // Database flow streams
    val feedPosts by repository.dao.getAllPostsFlow().collectAsState(initial = emptyList())
    val reels by repository.dao.getAllReelsFlow().collectAsState(initial = emptyList())
    val activeStories by remember { repository.dao.getActiveStoriesFlow(System.currentTimeMillis() - 24 * 3600 * 1000) }.collectAsState(initial = emptyList())
    val notificationsList by remember(currentUser) {
        repository.dao.getNotificationsFlow(currentUser?.username ?: "")
    }.collectAsState(initial = emptyList())

    // UI overlays & temporary state
    var showCreatePostDialog by remember { mutableStateOf(false) }
    var activeStoryViewerData by remember { mutableStateOf<StoryEntity?>(null) }
    var expandedPostCommentsId by remember { mutableStateOf<Int?>(null) }
    var showSportsSectionHub by remember { mutableStateOf(false) }
    var showNotificationsSheet by remember { mutableStateOf(false) }
    var selectedProfileUsernameViewer by remember { mutableStateOf<String?>(null) }
    var selectedProfilePhotoViewerUrl by remember { mutableStateOf<String?>(null) }

    // Navigation and core layout Scaffold
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        Text(
                            text = "Airmintrent",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = BrandMint
                            )
                        )
                        val greeting = currentUser?.username?.let { "@$it" } ?: "Good evening"
                        Text(
                            text = "Good evening, $greeting",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = BrandGray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToAI) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "AI Companion",
                            tint = BrandMint
                        )
                    }
                    IconButton(onClick = { showSportsSectionHub = true }) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "Sports Arena",
                            tint = BrandMint
                        )
                    }
                    IconButton(onClick = { showNotificationsSheet = true }) {
                        BadgedBox(
                            badge = {
                                if (notificationsList.isNotEmpty()) {
                                    Badge(
                                        containerColor = BrandRed,
                                        contentColor = Color.White
                                    ) {
                                        Text(notificationsList.size.toString(), fontSize = 9.sp)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Notifications",
                                tint = BrandCyan
                            )
                        }
                    }
                    IconButton(onClick = onNavigateToSafety) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Safety Center",
                            tint = BrandCyan
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BrandBg)
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = BrandSurface,
                contentColor = BrandMint
            ) {
                NavigationBarItem(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    icon = { Icon(if (activeTab == 0) Icons.Filled.Home else Icons.Outlined.Home, contentDescription = "Feed") },
                    label = { Text("Feed", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BrandMint,
                        selectedTextColor = BrandMint,
                        indicatorColor = BrandMuteBg,
                        unselectedIconColor = BrandGray,
                        unselectedTextColor = BrandGray
                    )
                )
                NavigationBarItem(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    icon = { Icon(if (activeTab == 1) Icons.Filled.Search else Icons.Outlined.Search, contentDescription = "Explore") },
                    label = { Text("Explore", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BrandMint,
                        selectedTextColor = BrandMint,
                        indicatorColor = BrandMuteBg,
                        unselectedIconColor = BrandGray,
                        unselectedTextColor = BrandGray
                    )
                )
                NavigationBarItem(
                    selected = activeTab == 2,
                    onClick = { activeTab = 2 },
                    icon = { Icon(if (activeTab == 2) Icons.Filled.PlayCircleFilled else Icons.Outlined.PlayCircle, contentDescription = "Reels") },
                    label = { Text("Reels", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BrandMint,
                        selectedTextColor = BrandMint,
                        indicatorColor = BrandMuteBg,
                        unselectedIconColor = BrandGray,
                        unselectedTextColor = BrandGray
                    )
                )
                NavigationBarItem(
                    selected = activeTab == 3,
                    onClick = { activeTab = 3 },
                    icon = { Icon(if (activeTab == 3) Icons.Filled.Mail else Icons.Outlined.Mail, contentDescription = "Chats") },
                    label = { Text("Chats", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BrandMint,
                        selectedTextColor = BrandMint,
                        indicatorColor = BrandMuteBg,
                        unselectedIconColor = BrandGray,
                        unselectedTextColor = BrandGray
                    )
                )
                NavigationBarItem(
                    selected = activeTab == 4,
                    onClick = { activeTab = 4 },
                    icon = { Icon(if (activeTab == 4) Icons.Filled.Person else Icons.Outlined.Person, contentDescription = "Profile") },
                    label = { Text("Profile", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BrandMint,
                        selectedTextColor = BrandMint,
                        indicatorColor = BrandMuteBg,
                        unselectedIconColor = BrandGray,
                        unselectedTextColor = BrandGray
                    )
                )
            }
        },
        floatingActionButton = {
            if (activeTab == 0) {
                FloatingActionButton(
                    onClick = { showCreatePostDialog = true },
                    containerColor = BrandMint,
                    contentColor = BrandBg,
                    modifier = Modifier.testTag("create_post_fab")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add Post")
                }
            }
        },
        containerColor = BrandBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main switch boards
            when (activeTab) {
                0 -> FeedTab(
                    posts = feedPosts,
                    stories = activeStories,
                    onStoryClick = { activeStoryViewerData = it },
                    onLikeToggle = { id -> coroutineScope.launch { repository.toggleLike(id) } },
                    onCommentClick = { id -> expandedPostCommentsId = id },
                    onShareClick = {
                        Toast.makeText(context, "🔗 Simulated share link copied to clipboard!", Toast.LENGTH_SHORT).show()
                    },
                    onReportToggle = { id ->
                        coroutineScope.launch {
                            repository.fileReport("POST", id.toString(), "User flag: general violation.")
                            Toast.makeText(context, "🚨 Post filed for moderation! Removed temporarily if spam.", Toast.LENGTH_LONG).show()
                        }
                    },
                    onProfileClick = { selectedProfileUsernameViewer = it },
                    repository = repository
                )

                1 -> ExploreTab(
                    repository = repository,
                    onLikeToggle = { id -> coroutineScope.launch { repository.toggleLike(id) } },
                    onCommentClick = { id -> expandedPostCommentsId = id },
                    onProfileClick = { selectedProfileUsernameViewer = it }
                )

                2 -> ReelsTab(reels = reels, repository = repository)

                3 -> DirectMessagesTab(repository = repository)

                4 -> ProfileTab(
                    repository = repository,
                    onLogout = onLogout,
                    onNavigateToAdmin = onNavigateToAdmin,
                    onNavigateToSafety = onNavigateToSafety
                )
            }

            // Create Post Sheet Dialog Overlay
            if (showCreatePostDialog) {
                CreatePostDialogSheet(
                    repository = repository,
                    onDismiss = { showCreatePostDialog = false }
                )
            }

            // Ephemeral Story full screen viewer
            if (activeStoryViewerData != null) {
                StoryViewerOverlay(
                    story = activeStoryViewerData!!,
                    repository = repository,
                    onDismiss = { activeStoryViewerData = null }
                )
            }

            // Comment Sheet Drawer
            if (expandedPostCommentsId != null) {
                CommentSheetDrawer(
                    postId = expandedPostCommentsId!!,
                    repository = repository,
                    onDismiss = { expandedPostCommentsId = null }
                )
            }

            // Sports Arena Hub
            if (showSportsSectionHub) {
                SportsStadiumHubOverlay(
                    repository = repository,
                    onDismiss = { showSportsSectionHub = false }
                )
            }

            // Notifications list Drawer Sheet
            if (showNotificationsSheet) {
                NotificationsSheetDrawer(
                    repository = repository,
                    onDismiss = { showNotificationsSheet = false }
                )
            }

            // User Profile details sheet
            if (selectedProfileUsernameViewer != null) {
                UserProfileViewerDialog(
                    username = selectedProfileUsernameViewer!!,
                    repository = repository,
                    onDismiss = { selectedProfileUsernameViewer = null },
                    onPhotoClick = { photoUrl ->
                        selectedProfilePhotoViewerUrl = photoUrl
                    }
                )
            }

            // Profile photo zoom lightbox
            if (selectedProfilePhotoViewerUrl != null) {
                ProfilePhotoFullscreenLightbox(
                    url = selectedProfilePhotoViewerUrl,
                    onDismiss = { selectedProfilePhotoViewerUrl = null }
                )
            }
        }
    }
}

// --- Feed Composable View ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedTab(
    posts: List<PostEntity>,
    stories: List<StoryEntity>,
    onStoryClick: (StoryEntity) -> Unit,
    onLikeToggle: (Int) -> Unit,
    onCommentClick: (Int) -> Unit,
    onShareClick: (Int) -> Unit,
    onReportToggle: (Int) -> Unit,
    onProfileClick: (String) -> Unit,
    repository: AppRepository
) {
    val currentUser by repository.currentUser.collectAsState()
    val blockedUsers by remember(currentUser) { 
        repository.dao.getBlockedUsernamesFlow(currentUser?.username ?: "") 
    }.collectAsState(initial = emptyList())

    // Prevent displaying content from blocked users
    val filteredPosts = posts.filter { 
        !blockedUsers.contains(it.authorUsername) && !it.isSpam
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Horizontal Stories listing
        if (stories.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(vertical = 8.dp)) {
                    Text(
                        text = "Stories • Live Circle",
                        style = MaterialTheme.typography.labelMedium.copy(color = BrandGray, fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(stories) { story ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clickable { onProfileClick(story.authorUsername) }
                                    .padding(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(CircleShape)
                                        .border(2.dp, BrandMint, CircleShape)
                                        .padding(4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    AsyncImage(
                                        model = story.authorProfilePic,
                                        contentDescription = "Story Author",
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(CircleShape)
                                            .clickable { onStoryClick(story) },
                                        contentScale = ContentScale.Crop
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = story.authorUsername,
                                    fontSize = 11.sp,
                                    color = BrandOffWhite,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.width(64.dp),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }

        // Main Feed posts items
        if (filteredPosts.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(60.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.CloudQueue, contentDescription = null, tint = BrandGray, modifier = Modifier.size(50.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            "Nothing in the breeze today. Post first!",
                            style = MaterialTheme.typography.bodyMedium.copy(color = BrandGray),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(filteredPosts) { post ->
                PostItemCard(
                    post = post,
                    repository = repository,
                    onLike = { onLikeToggle(post.id) },
                    onComment = { onCommentClick(post.id) },
                    onShare = { onShareClick(post.id) },
                    onReport = { onReportToggle(post.id) },
                    onProfileClick = onProfileClick
                )
            }
        }
    }
}

// --- Post Item Layout Composable ---

@Composable
fun PostItemCard(
    post: PostEntity,
    repository: AppRepository,
    onLike: () -> Unit,
    onComment: () -> Unit,
    onShare: () -> Unit,
    onReport: () -> Unit,
    onProfileClick: (String) -> Unit
) {
    val currentUser by repository.currentUser.collectAsState()
    val isLiked by remember(currentUser) { 
        repository.dao.isPostLikedFlow(post.id, currentUser?.username ?: "") 
    }.collectAsState(initial = false)

    val savedPostIds by repository.savedPostIds.collectAsState()
    val isSaved = savedPostIds.contains(post.id)

    var showOptions by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .testTag("post_card_${post.id}"),
        colors = CardDefaults.cardColors(containerColor = BrandSurface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onProfileClick(post.authorUsername) }
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(BrandMuteBg)
                    ) {
                        AsyncImage(
                            model = post.authorProfilePic,
                            contentDescription = "Profile",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = post.authorName,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = BrandOffWhite)
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "@${post.authorUsername}",
                                style = MaterialTheme.typography.labelSmall.copy(color = BrandGray)
                            )
                            if (post.location.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = BrandMint, modifier = Modifier.size(10.dp))
                                // Parse clean location address line
                                val cleanLocation = if (post.location.contains("| Track:")) post.location.split("| Track:")[0].trim() else post.location
                                Text(cleanLocation, style = MaterialTheme.typography.labelSmall.copy(color = BrandMint, fontSize = 9.sp))
                            }
                        }
                    }
                }

                // Options gear/dots
                Box {
                    IconButton(onClick = { showOptions = true }) {
                        Icon(imageVector = Icons.Default.MoreVert, contentDescription = "Post Options", tint = BrandGray)
                    }
                    DropdownMenu(
                        expanded = showOptions,
                        onDismissRequest = { showOptions = false },
                        modifier = Modifier.background(BrandSurfaceLighter)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Report Post", color = BrandRed) },
                            onClick = { onReport(); showOptions = false }
                        )
                        DropdownMenuItem(
                            text = { Text("Block @${post.authorUsername}", color = BrandGray) },
                            onClick = { 
                                showOptions = false 
                                coroutineScope.launch {
                                    repository.blockUser(post.authorUsername)
                                }
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Body content
            Text(
                text = post.content,
                style = MaterialTheme.typography.bodyMedium.copy(color = BrandOffWhite, lineHeight = 20.sp)
            )

            // Attached Soundtrack details if present
            if (post.location.contains("| Track:")) {
                val songTitle = post.location.split("| Track:").getOrNull(1)?.trim() ?: ""
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(BrandMuteBg, RoundedCornerShape(16.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(imageVector = Icons.Default.MusicNote, contentDescription = "Song", tint = BrandMint, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = songTitle, fontSize = 9.sp, color = BrandMint, fontWeight = FontWeight.Bold)
                }
            }

            // Image Carousel support / Videos representation
            if (post.mediaUrl.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                val urls = remember(post.mediaUrl) {
                    if (post.mediaUrl.contains(",")) post.mediaUrl.split(",").map { it.trim() } else listOf(post.mediaUrl)
                }
                var activeIndex by remember { mutableStateOf(0) }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(BrandMuteBg)
                ) {
                    AsyncImage(
                        model = urls[activeIndex],
                        contentDescription = "Post attachment asset",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )

                    // Play video overlay
                    if (post.mediaType == "VIDEO" || urls[activeIndex].contains(".mp4") || urls[activeIndex].contains("video")) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.5f))
                                .align(Alignment.Center),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Play Video", tint = BrandMint, modifier = Modifier.size(24.dp))
                        }
                    }

                    // Left & Right pagers
                    if (urls.size > 1) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.Center)
                                .padding(horizontal = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            IconButton(
                                onClick = { activeIndex = (activeIndex - 1 + urls.size) % urls.size },
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.4f))
                            ) {
                                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Prev", tint = Color.White, modifier = Modifier.size(16.dp))
                            }

                            IconButton(
                                onClick = { activeIndex = (activeIndex + 1) % urls.size },
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.4f))
                            ) {
                                Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "Next", tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }

                        // Dot slider indicators
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            urls.forEachIndexed { idx, _ ->
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(if (idx == activeIndex) BrandMint else Color.White.copy(alpha = 0.5f))
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Actions panel footer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Like Button
                Row(
                    modifier = Modifier
                        .clickable { onLike() }
                        .padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Like",
                        tint = if (isLiked) BrandRed else BrandGray,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = post.likesCount.toString(), style = MaterialTheme.typography.bodySmall.copy(color = BrandGray))
                }

                // Comment Button
                Row(
                    modifier = Modifier
                        .clickable { onComment() }
                        .padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ChatBubbleOutline,
                        contentDescription = "Comment",
                        tint = BrandGray,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = post.commentsCount.toString(), style = MaterialTheme.typography.bodySmall.copy(color = BrandGray))
                }

                // Bookmark / Save Post Button
                IconButton(
                    onClick = {
                        coroutineScope.launch {
                            repository.toggleSavePost(post.id)
                        }
                    }
                ) {
                    Icon(
                        imageVector = if (isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = "Save Post",
                        tint = if (isSaved) BrandMint else BrandGray,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Share Button
                IconButton(onClick = onShare) {
                    Icon(imageVector = Icons.Outlined.Share, contentDescription = "Share", tint = BrandGray, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

// --- Explore & Search Screen Composable ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreTab(
    repository: AppRepository,
    onLikeToggle: (Int) -> Unit,
    onCommentClick: (Int) -> Unit,
    onProfileClick: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<PostEntity>>(emptyList()) }
    var searchUsersResults by remember { mutableStateOf<List<UserEntity>>(emptyList()) }
    var isSearching by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()
    val trendingTopics = listOf("#Airmintrent", "#FutureIsNear", "#BreezeCircle", "#CryptoShield", "#CodeArt", "#TravelLapland")

    Column(modifier = Modifier.fillMaxSize()) {
        // Modern Floating styled Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { query ->
                searchQuery = query
                isSearching = query.isNotEmpty()
                coroutineScope.launch {
                    if (query.isNotEmpty()) {
                        searchResults = repository.dao.searchPosts("%$query%")
                        searchUsersResults = repository.dao.searchUsers("%$query%")
                    } else {
                        searchResults = emptyList()
                        searchUsersResults = emptyList()
                    }
                }
            },
            placeholder = { Text("Search users, tags, keywords...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = BrandMint) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = ""; isSearching = false }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = BrandGray)
                    }
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrandMint,
                unfocusedBorderColor = BrandSurfaceLighter,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        if (!isSearching) {
            // Hot Topics & Trending Layout View
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = "🔥 Trending Hashtags",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    trendingTopics.take(3).forEach { hashtag ->
                        TrendingHashtagButton(hashtag = hashtag, onClick = { searchQuery = hashtag.removePrefix("#") })
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    trendingTopics.drop(3).forEach { hashtag ->
                        TrendingHashtagButton(hashtag = hashtag, onClick = { searchQuery = hashtag.removePrefix("#") })
                    }
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Welcome and quick guidelines card space inside explore
                Card(
                    colors = CardDefaults.cardColors(containerColor = BrandSurface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Search Instruction Notes", style = MaterialTheme.typography.titleSmall.copy(color = BrandMint, fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Enter usernames, display handles, or content keywords like 'Swedish' or 'Lapland' (from seed posts) to test instant search reactivity.", style = MaterialTheme.typography.bodySmall.copy(color = BrandGray))
                    }
                }
            }
        } else {
            // Live Search results
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Users Result Category
                if (searchUsersResults.isNotEmpty()) {
                    item {
                        Text(
                            "Found Profiles",
                            style = MaterialTheme.typography.labelMedium.copy(color = BrandGray, fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                    items(searchUsersResults) { u ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BrandSurface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp)
                                .clickable { onProfileClick(u.username) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(BrandMuteBg)) {
                                        AsyncImage(model = u.profilePicUrl, contentDescription = null, modifier = Modifier.fillMaxSize())
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(u.fullName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                                        Text("@${u.username}", style = MaterialTheme.typography.bodySmall.copy(color = BrandGray))
                                    }
                                }
                                
                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            repository.toggleFollow(u.username)
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                                    modifier = Modifier.height(30.dp),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text("Follow Circle", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Posts Result Category
                if (searchResults.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            "Found Posts Content",
                            style = MaterialTheme.typography.labelMedium.copy(color = BrandGray, fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }

                    items(searchResults) { post ->
                        PostItemCard(
                            post = post,
                            repository = repository,
                            onLike = { onLikeToggle(post.id) },
                            onComment = { onCommentClick(post.id) },
                            onShare = {},
                            onReport = {},
                            onProfileClick = onProfileClick
                        )
                    }
                }

                if (searchUsersResults.isEmpty() && searchResults.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No posts or profiles matched query keys.", style = MaterialTheme.typography.bodySmall.copy(color = BrandGray))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TrendingHashtagButton(hashtag: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(BrandSurface, RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.TrendingUp, contentDescription = null, tint = BrandMint, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(hashtag, style = MaterialTheme.typography.bodySmall.copy(color = Color.White))
        }
    }
}

// --- Reels (TikTok Shorts Simulator) ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReelsTab(reels: List<ReelEntity>, repository: AppRepository) {
    if (reels.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No Reels loaded. Create Chef plates soon!", style = MaterialTheme.typography.bodySmall.copy(color = BrandGray))
        }
        return
    }

    var selectedReelIndex by remember { mutableStateOf(0) }
    val reel = reels[selectedReelIndex % reels.size]

    val likedReelIds by repository.likedReelIds.collectAsState()
    val isLiked = likedReelIds.contains(reel.id)

    val reelCommentsMap by repository.reelComments.collectAsState()
    val reelCommentsList = reelCommentsMap[reel.id] ?: emptyList()

    var showCommentsDialog by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("reels_scaffold")
    ) {
        // Video Mock Image content layout
        AsyncImage(
            model = reel.videoUrl,
            contentDescription = "Reel Background Video Thumbnail",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Dark overlay gradient to ensure high readability of texts
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f)),
                        startY = 300f
                    )
                )
        )

        // Bottom Details text
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
                .fillMaxWidth(0.8f)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(32.dp).clip(CircleShape).background(BrandMuteBg)) {
                    AsyncImage(model = reel.authorProfilePic, contentDescription = null, modifier = Modifier.fillMaxSize())
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(reel.authorName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                Spacer(modifier = Modifier.width(6.dp))
                Text("@${reel.authorUsername}", style = MaterialTheme.typography.labelSmall.copy(color = BrandMint))
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(reel.content, maxLines = 2, style = MaterialTheme.typography.bodySmall.copy(color = BrandOffWhite))
            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.MusicNote, contentDescription = "Audio track", tint = BrandMint, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(reel.audioTrack, fontSize = 10.sp, color = BrandMint)
            }
        }

        // Right hand vertical action keys panel
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Like
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(
                    onClick = {
                        coroutineScope.launch {
                            repository.toggleReelLike(reel.id)
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Filled.Favorite,
                        contentDescription = "Like Reel",
                        tint = if (isLiked) BrandRed else Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }
                Text("${reel.likesCount + if (isLiked) 1 else 0}", fontSize = 11.sp, color = Color.White)
            }

            // Comment
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(onClick = { showCommentsDialog = true }) {
                    Icon(
                        imageVector = Icons.Filled.Comment,
                        contentDescription = "Reel Comments",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
                Text("${reel.commentsCount + reelCommentsList.size}", fontSize = 11.sp, color = Color.White)
            }

            // Swipe Up Next button helper
            IconButton(
                onClick = { selectedReelIndex++ },
                modifier = Modifier
                    .size(44.dp)
                    .background(BrandSurface, CircleShape)
            ) {
                Icon(Icons.Default.ArrowDownward, contentDescription = "Next Reel", tint = BrandMint)
            }
            Text("Next", fontSize = 10.sp, color = BrandGray)
        }

        // Reels Comments Dialog Sheet
        if (showCommentsDialog) {
            AlertDialog(
                onDismissRequest = { showCommentsDialog = false },
                title = { Text("Reel Conversation", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 350.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        LazyColumn(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (reelCommentsList.isEmpty()) {
                                item {
                                    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                                        Text("No comments on this audio track yet. Express your style below!", style = MaterialTheme.typography.bodySmall.copy(color = BrandGray), textAlign = TextAlign.Center)
                                    }
                                }
                            } else {
                                items(reelCommentsList) { comment ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(28.dp)
                                                .clip(CircleShape)
                                                .background(Color.Gray)
                                        ) {
                                            AsyncImage(model = comment.authorProfilePic, contentDescription = null, modifier = Modifier.fillMaxSize())
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(comment.authorName, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = BrandOffWhite))
                                            Text(comment.content, style = MaterialTheme.typography.bodyMedium.copy(color = Color.White))
                                        }
                                    }
                                }
                            }
                        }

                        // Input field to write comments
                        var newCommentText by remember { mutableStateOf("") }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedTextField(
                                value = newCommentText,
                                onValueChange = { newCommentText = it },
                                placeholder = { Text("Add comment...", color = Color.Gray, fontSize = 12.sp) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = BrandMint,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                                    focusedContainerColor = BrandMuteBg,
                                    unfocusedContainerColor = BrandMuteBg.copy(alpha = 0.5f)
                                ),
                                shape = RoundedCornerShape(20.dp),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )

                            IconButton(
                                onClick = {
                                    if (newCommentText.isNotBlank()) {
                                        coroutineScope.launch {
                                            repository.addReelComment(reel.id, newCommentText)
                                            newCommentText = ""
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(BrandMint, CircleShape),
                                enabled = newCommentText.isNotBlank()
                            ) {
                                Icon(imageVector = Icons.Default.Send, contentDescription = "Send", tint = BrandSurface, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showCommentsDialog = false }) {
                        Text("Close", color = BrandMint)
                    }
                },
                containerColor = BrandSurface
            )
        }
    }
}

// --- DM Chats Composable with Recording System ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DirectMessagesTab(repository: AppRepository) {
    // Live Users List for picking conversations
    val allDbUsers by repository.dao.getAllUsersFlow().collectAsState(initial = emptyList())
    val currentUser by repository.currentUser.collectAsState()
    val activeChat by repository.activeChatUser.collectAsState()

    var textMessage by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()

    // Recording states
    var isRecording by remember { mutableStateOf(false) }
    var recordTimeTicks by remember { mutableStateOf(0) }

    // Media Sharing & Dialog states
    var showImageShareDialog by remember { mutableStateOf(false) }
    var showVideoShareDialog by remember { mutableStateOf(false) }
    var mediaUrlInput by remember { mutableStateOf("") }

    // Voice playback states
    var playingVoiceId by remember { mutableStateOf<Int?>(null) }
    var voicePlaybackProgress by remember { mutableStateOf(0f) }

    val activeRecipient = activeChat

    // Voice progress ticking
    LaunchedEffect(playingVoiceId) {
        if (playingVoiceId != null) {
            voicePlaybackProgress = 0f
            while (playingVoiceId != null && voicePlaybackProgress < 1f) {
                delay(150)
                voicePlaybackProgress += 0.05f
            }
            playingVoiceId = null
            voicePlaybackProgress = 0f
        }
    }

    if (activeRecipient == null) {
        // Conversation List Selection Mode
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Text(
                    "Selected Active Circles Chat Contacts",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White),
                    modifier = Modifier.padding(16.dp)
                )
            }

            items(allDbUsers.filter { it.username != currentUser?.username }) { peer ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp)
                        .clickable { repository.activeChatUser.value = peer },
                    colors = CardDefaults.cardColors(containerColor = BrandSurface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Profile with Online Status Spot
                        Box(modifier = Modifier.size(52.dp)) {
                            Box(modifier = Modifier.size(48.dp).clip(CircleShape).background(BrandMuteBg).align(Alignment.TopStart)) {
                                AsyncImage(model = peer.profilePicUrl, contentDescription = peer.fullName, modifier = Modifier.fillMaxSize())
                            }
                            // Glow Green Status Indicator (simulated online by default for circles)
                            Box(
                                modifier = Modifier
                                    .size(13.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF00FF66))
                                    .border(2.dp, BrandSurface, CircleShape)
                                    .align(Alignment.BottomEnd)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(peer.fullName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                            Text("@${peer.username} • Online active", style = MaterialTheme.typography.bodySmall.copy(color = BrandMint, fontSize = 10.sp))
                        }
                    }
                }
            }
        }
    } else {
        // Chat History Session Active View
        val chatLogs by remember(activeRecipient.username, currentUser?.username) {
            repository.dao.getMessagesBetweenUsersFlow(currentUser?.username ?: "", activeRecipient.username)
        }.collectAsState(initial = emptyList())

        // Timer recording coroutine loop
        LaunchedEffect(isRecording) {
            if (isRecording) {
                recordTimeTicks = 0
                while (isRecording) {
                    delay(1000)
                    recordTimeTicks++
                }
            }
        }

        Column(modifier = Modifier.fillMaxSize()) {
            // Recipient active header info Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BrandSurface)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { repository.activeChatUser.value = null }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = BrandMint)
                }
                // Header Profile Photo with Online Badge
                Box(modifier = Modifier.size(36.dp)) {
                    Box(modifier = Modifier.size(32.dp).clip(CircleShape).background(BrandMuteBg).align(Alignment.TopStart)) {
                        AsyncImage(model = activeRecipient.profilePicUrl, contentDescription = null, modifier = Modifier.fillMaxSize())
                    }
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00FF66))
                            .border(1.5.dp, BrandSurface, CircleShape)
                            .align(Alignment.BottomEnd)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(activeRecipient.fullName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                    Text("Secure chat verified • Active Now", style = MaterialTheme.typography.labelSmall.copy(color = BrandMint))
                }
            }

            // Message scrolling feed View
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(chatLogs) { msg ->
                    val isMyMsg = msg.senderUsername == currentUser?.username
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (isMyMsg) Arrangement.End else Arrangement.Start
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isMyMsg) BrandMuteBg else BrandSurface
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                if (msg.isVoice) {
                                    // Custom Interactive Voice Message Player
                                    val isThisPlaying = playingVoiceId == msg.id
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(onClick = {
                                            playingVoiceId = if (isThisPlaying) null else msg.id
                                        }) {
                                            Icon(
                                                imageVector = if (isThisPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                contentDescription = "Play voice message",
                                                tint = BrandMint
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Column {
                                            Text(
                                                "Secure Voice Thread",
                                                style = MaterialTheme.typography.labelSmall.copy(color = BrandMint, fontWeight = FontWeight.Bold)
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            // sound waveform indicator
                                            Row(
                                                modifier = Modifier.height(14.dp),
                                                horizontalArrangement = Arrangement.spacedBy(2.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                repeat(12) { runIdx ->
                                                    val active = isThisPlaying && (runIdx / 12f) <= voicePlaybackProgress
                                                    Box(
                                                        modifier = Modifier
                                                            .width(2.dp)
                                                            .fillMaxHeight(remember(msg.id, runIdx) { (3..10).random() / 10f })
                                                            .background(if (active) BrandMint else BrandGray)
                                                    )
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                if (isThisPlaying) "Playing Node (0:0${(voicePlaybackProgress * 4).toInt()})" else msg.voiceDuration,
                                                style = MaterialTheme.typography.bodySmall.copy(color = BrandGray, fontSize = 9.sp)
                                            )
                                        }
                                    }
                                } else if (msg.content.startsWith("[IMAGE]")) {
                                    val imageUrl = msg.content.removePrefix("[IMAGE]")
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .width(190.dp)
                                                .height(130.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                        ) {
                                            AsyncImage(
                                                model = imageUrl,
                                                contentDescription = "Shared Image",
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop
                                            )
                                        }
                                        Text("Shared Picture", fontSize = 10.sp, color = BrandCyan, fontWeight = FontWeight.Bold)
                                    }
                                } else if (msg.content.startsWith("[VIDEO]")) {
                                    val videoUrl = msg.content.removePrefix("[VIDEO]")
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .width(190.dp)
                                                .height(130.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(Color.Black)
                                        ) {
                                            AsyncImage(
                                                model = "https://images.unsplash.com/photo-1540747737956-378724044282?auto=format&fit=crop&w=300&q=80",
                                                contentDescription = "Video preview poster",
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop,
                                                alpha = 0.5f
                                            )
                                            Icon(
                                                imageVector = Icons.Default.PlayCircle,
                                                contentDescription = "Play shared video",
                                                tint = BrandMint,
                                                modifier = Modifier.size(36.dp).align(Alignment.Center)
                                            )
                                        }
                                        Text("Shared Video Clip", fontSize = 10.sp, color = BrandMint, fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    Text(msg.content, style = MaterialTheme.typography.bodyMedium.copy(color = Color.White))
                                }
                            }
                        }
                    }
                }
            }

            // Quick Media Shortcuts Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BrandSurface)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Share Media:", style = MaterialTheme.typography.labelSmall.copy(color = BrandGray, fontWeight = FontWeight.Bold))
                
                IconButton(onClick = { showImageShareDialog = true }, modifier = Modifier.size(28.dp)) {
                    Icon(imageVector = Icons.Default.Image, contentDescription = "Send Image preset", tint = BrandCyan, modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = { showVideoShareDialog = true }, modifier = Modifier.size(28.dp)) {
                    Icon(imageVector = Icons.Default.VideoLibrary, contentDescription = "Send Video preset", tint = BrandMint, modifier = Modifier.size(16.dp))
                }
            }

            // Message Composer Controls Input Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BrandSurface)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isRecording) {
                    // Record timer countdown and visual waveforms
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.FiberManualRecord, contentDescription = "Recording", tint = BrandRed, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Recording sound... 0:${recordTimeTicks.toString().padStart(2, '0')}", style = MaterialTheme.typography.bodySmall.copy(color = Color.Red))
                    }
                    Button(
                        onClick = {
                            isRecording = false
                            coroutineScope.launch {
                                repository.sendMessage(
                                    recipientUsername = activeRecipient.username,
                                    content = "[Voice Node]",
                                    isVoice = true,
                                    voiceDuration = "0:${recordTimeTicks.toString().padStart(2, '0')} voice note."
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandRed, contentColor = Color.White)
                    ) {
                        Text("Send Node", fontSize = 11.sp)
                    }
                } else {
                    // Normal text typing input
                    OutlinedTextField(
                        value = textMessage,
                        onValueChange = { textMessage = it },
                        placeholder = { Text("Compose secure DM...") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Spacer(modifier = Modifier.width(6.dp))

                    if (textMessage.isEmpty()) {
                        // Mic Button for recording voice messages
                        IconButton(onClick = { isRecording = true }) {
                            Icon(Icons.Default.Mic, contentDescription = "Record voice node", tint = BrandMint)
                        }
                    } else {
                        IconButton(
                            onClick = {
                                val text = textMessage
                                textMessage = ""
                                coroutineScope.launch {
                                    repository.sendMessage(
                                        recipientUsername = activeRecipient.username,
                                        content = text
                                    )
                                }
                            }
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = BrandMint)
                        }
                    }
                }
            }
        }
    }

    // Image Sharing Dialog Options
    if (showImageShareDialog && activeRecipient != null) {
        AlertDialog(
            onDismissRequest = { showImageShareDialog = false },
            title = { Text("Share Aesthetic Image Circle", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select a preset circle photo or paste customized picture URL:", color = BrandOffWhite, fontSize = 11.sp)
                    
                    OutlinedTextField(
                        value = mediaUrlInput,
                        onValueChange = { mediaUrlInput = it },
                        placeholder = { Text("https://example.com/photo.jpg") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )

                    Text("Presets:", color = BrandGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val imagesList = listOf(
                            "Aurora Night" to "https://images.unsplash.com/photo-1579033461380-adb47c3eb938?auto=format&fit=crop&w=200&q=80",
                            "Cyber Tokyo" to "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?auto=format&fit=crop&w=200&q=80",
                            "Vibrant Sunrise" to "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=200&q=80"
                        )
                        imagesList.forEach { (label, presetUrl) ->
                            Button(
                                onClick = {
                                    mediaUrlInput = presetUrl
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = BrandSurfaceLighter, contentColor = Color.White),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(label, fontSize = 8.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val finalUrl = mediaUrlInput.ifBlank { "https://images.unsplash.com/photo-1579033461380-adb47c3eb938?auto=format&fit=crop&w=600&q=80" }
                        coroutineScope.launch {
                            repository.sendMessage(recipientUsername = activeRecipient.username, content = "[IMAGE]$finalUrl")
                        }
                        mediaUrlInput = ""
                        showImageShareDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg)
                ) {
                    Text("Attach Circle Photo")
                }
            },
            dismissButton = {
                TextButton(onClick = { showImageShareDialog = false }) {
                    Text("Cancel", color = BrandRed)
                }
            },
            containerColor = BrandSurface
        )
    }

    // Video Sharing Dialog Options
    if (showVideoShareDialog && activeRecipient != null) {
        AlertDialog(
            onDismissRequest = { showVideoShareDialog = false },
            title = { Text("Share Athletic Video Clip", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select a video clip preset or register a secure media stream URL:", color = BrandOffWhite, fontSize = 11.sp)
                    
                    OutlinedTextField(
                        value = mediaUrlInput,
                        onValueChange = { mediaUrlInput = it },
                        placeholder = { Text("https://example.com/video.mp4") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )

                    Text("Presets Video Streams:", color = BrandGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val videoPresets = listOf(
                            "F1 Race Track" to "https://assets.mixkit.co/videos/preview/mixkit-f1-cars-race-track-34674-large.mp4",
                            "Campfire Spark" to "https://assets.mixkit.co/videos/preview/mixkit-camp-fire-in-the-woods-at-night-3413-large.mp4",
                            "Futuristic Metro" to "https://assets.mixkit.co/videos/preview/mixkit-subway-train-moving-fast-in-a-city-43610-large.mp4"
                        )
                        videoPresets.forEach { (label, presetUrl) ->
                            Button(
                                onClick = {
                                    mediaUrlInput = presetUrl
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = BrandSurfaceLighter, contentColor = Color.White),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(label, fontSize = 8.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val finalUrl = mediaUrlInput.ifBlank { "https://assets.mixkit.co/videos/preview/mixkit-f1-cars-race-track-34674-large.mp4" }
                        coroutineScope.launch {
                            repository.sendMessage(recipientUsername = activeRecipient.username, content = "[VIDEO]$finalUrl")
                        }
                        mediaUrlInput = ""
                        showVideoShareDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg)
                ) {
                    Text("Send Clip Video")
                }
            },
            dismissButton = {
                TextButton(onClick = { showVideoShareDialog = false }) {
                    Text("Cancel", color = BrandRed)
                }
            },
            containerColor = BrandSurface
        )
    }
}

// --- Profile Composable View ---

@Composable
fun ProfileTab(
    repository: AppRepository,
    onLogout: () -> Unit,
    onNavigateToAdmin: () -> Unit,
    onNavigateToSafety: () -> Unit
) {
    val currentUser by repository.currentUser.collectAsState()
    val context = LocalContext.current
    var isPrivateState by remember { mutableStateOf(currentUser?.isPrivate ?: false) }
    val coroutineScope = rememberCoroutineScope()

    // Dialog state
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var editFullName by remember(currentUser) { mutableStateOf(currentUser?.fullName ?: "") }
    var editUsername by remember(currentUser) { mutableStateOf(currentUser?.username ?: "") }
    var editBio by remember(currentUser) { mutableStateOf(currentUser?.bio ?: "") }
    var editProfilePicUrl by remember(currentUser) { mutableStateOf(currentUser?.profilePicUrl ?: "") }
    var updateErrorMsg by remember { mutableStateOf<String?>(null) }

    // Presence status toggle
    var presenceStatus by remember { mutableStateOf("Online") } // Online, Busy, Invisible

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Profile Portrait with pulsing Presence status indicator
            Box(
                modifier = Modifier.size(105.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(90.dp)
                        .clip(CircleShape)
                        .background(BrandSurface)
                        .border(2.dp, BrandMint, CircleShape)
                        .align(Alignment.TopStart)
                ) {
                    AsyncImage(
                        model = editProfilePicUrl.ifBlank { currentUser?.profilePicUrl },
                        contentDescription = "Portrait Avatar",
                        modifier = Modifier.fillMaxSize()
                    )
                }
                
                // Presence Spot Ring Indicator
                val spotColor = when (presenceStatus) {
                    "Online" -> Color(0xFF00FF66)
                    "Busy" -> Color(0xFFFF3366)
                    else -> Color(0xFF888888)
                }
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(spotColor)
                        .border(3.dp, BrandBg, CircleShape)
                        .align(Alignment.BottomEnd)
                )
            }
        }

        item {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = currentUser?.fullName ?: "Creator Identity",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = Color.White)
                )
                Text(
                    text = "@${currentUser?.username ?: "username"}",
                    style = MaterialTheme.typography.bodyMedium.copy(color = BrandGray)
                )
                Spacer(modifier = Modifier.height(8.dp))
                
                // Toggle status Presence Chips Row
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("Online", "Busy", "Invisible").forEach { status ->
                        val isSelected = presenceStatus == status
                        val chipBg = if (isSelected) {
                            when (status) {
                                "Online" -> Color(0xFF00FF66).copy(alpha = 0.2f)
                                "Busy" -> Color(0xFFFF3366).copy(alpha = 0.2f)
                                else -> Color(0xFF888888).copy(alpha = 0.2f)
                            }
                        } else BrandSurface
                        val chipText = if (isSelected) {
                            when (status) {
                                "Online" -> Color(0xFF00FF66)
                                "Busy" -> Color(0xFFFF3366)
                                else -> Color.White
                            }
                        } else BrandGray

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(chipBg)
                                .border(1.dp, if (isSelected) chipText else Color.Transparent, RoundedCornerShape(12.dp))
                                .clickable { presenceStatus = status }
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(status, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = chipText)
                        }
                    }
                }
            }
        }

        item {
            // Edit profile button action trigger
            Button(
                onClick = { 
                    updateErrorMsg = null
                    showEditProfileDialog = true 
                },
                modifier = Modifier.fillMaxWidth(0.8f),
                colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Profile Info", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Edit Profile Details", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        item {
            // Quick Counts Stats Card Spacer
            Card(
                colors = CardDefaults.cardColors(containerColor = BrandSurface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Circle Followers", fontSize = 10.sp, color = BrandGray)
                        Text("${currentUser?.followersCount ?: 0}", style = MaterialTheme.typography.bodyLarge.copy(color = BrandMint, fontWeight = FontWeight.Bold))
                    }
                    VerticalDivider(modifier = Modifier.height(24.dp), color = BrandSurfaceLighter)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Wavelengths", fontSize = 10.sp, color = BrandGray)
                        Text("${currentUser?.followingCount ?: 0}", style = MaterialTheme.typography.bodyLarge.copy(color = BrandCyan, fontWeight = FontWeight.Bold))
                    }
                }
            }
        }

        item {
            // Account bio
            Text(
                text = currentUser?.bio ?: "No profile bio created yet.",
                style = MaterialTheme.typography.bodyMedium.copy(color = BrandOffWhite, textAlign = TextAlign.Center),
                modifier = Modifier.padding(horizontal = 12.dp)
            )
        }

        item {
            // Privacy settings Controls
            Card(
                colors = CardDefaults.cardColors(containerColor = BrandSurface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Privacy Preference Controls", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Private Account Circle", style = MaterialTheme.typography.labelSmall.copy(color = BrandOffWhite))
                            Text("Only accepted connections view posts", fontSize = 10.sp, color = BrandGray)
                        }
                        Switch(
                            checked = isPrivateState,
                            onCheckedChange = { chk ->
                                isPrivateState = chk
                                coroutineScope.launch {
                                    val dbUser = repository.dao.getUserByUsername(currentUser?.username ?: "")
                                    if (dbUser != null) {
                                        repository.dao.updateUser(dbUser.copy(isPrivate = chk))
                                    }
                                }
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = BrandMint)
                        )
                    }
                }
            }
        }

        item {
            // Admin Panel short gears if they entry
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // If they are admin trigger: we can let everyone test admin properties easily for review convenience!
                Button(
                    onClick = onNavigateToAdmin,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandSurfaceLighter, contentColor = BrandMint)
                ) {
                    Icon(imageVector = Icons.Default.AdminPanelSettings, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Admin Reviews Dashboard")
                }

                Button(
                    onClick = onLogout,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandMuteBg, contentColor = BrandRed)
                ) {
                    Text("Disconnect Profile Sessions (Logout)")
                }
            }
        }
    }

    // Edit Profile Details Modal sheet Dialog
    if (showEditProfileDialog) {
        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            title = { Text("Edit Creator Credentials", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
            text = {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        if (updateErrorMsg != null) {
                            Text(updateErrorMsg!!, color = Color.Red, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
                        }
                    }

                    item {
                        Text("Full Name Display Name:", color = BrandGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = editFullName,
                            onValueChange = { editFullName = it },
                            placeholder = { Text("Display full name") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )
                    }

                    item {
                        Text("Creator Username (@handle):", color = BrandGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = editUsername,
                            onValueChange = { editUsername = it },
                            placeholder = { Text("Unique username handle") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )
                    }

                    item {
                        Text("Personal Creator Bio:", color = BrandGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = editBio,
                            onValueChange = { editBio = it },
                            placeholder = { Text("Describe yourself or your dynamic circle niche...") },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )
                    }

                    item {
                        Text("Photo Avatar Source Link URL:", color = BrandGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = editProfilePicUrl,
                            onValueChange = { editProfilePicUrl = it },
                            placeholder = { Text("https://...") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )
                    }

                    item {
                        Text("Or Select A Preset Circle Avatar:", color = BrandGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val presetAvatars = listOf(
                                "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80",
                                "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80",
                                "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80",
                                "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
                            )
                            presetAvatars.forEachIndexed { index, url ->
                                Box(
                                    modifier = Modifier
                                        .size(45.dp)
                                        .clip(CircleShape)
                                        .background(BrandSurface)
                                        .border(2.dp, if (editProfilePicUrl == url) BrandMint else Color.Transparent, CircleShape)
                                        .clickable { editProfilePicUrl = url }
                                ) {
                                    AsyncImage(model = url, contentDescription = null, modifier = Modifier.fillMaxSize())
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            val originalUsername = currentUser?.username ?: ""
                            val result = repository.updateProfileDetail(
                                fullName = editFullName,
                                bio = editBio,
                                profilePicUrl = editProfilePicUrl,
                                newUsername = editUsername,
                                isPrivate = isPrivateState
                            )
                            when (result) {
                                is AppRepository.ProfileUpdateResult.Success -> {
                                    Toast.makeText(context, "🍃 Profile credentials updated safely!", Toast.LENGTH_SHORT).show()
                                    showEditProfileDialog = false
                                }
                                is AppRepository.ProfileUpdateResult.Error -> {
                                    updateErrorMsg = result.message
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg)
                ) {
                    Text("Save Changes", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) {
                    Text("Discard", color = BrandRed)
                }
            },
            containerColor = BrandSurface
        )
    }
}

// --- Create Post Overlay Composable ---

@Composable
fun CreatePostDialogSheet(
    repository: AppRepository,
    onDismiss: () -> Unit
) {
    var contentText by remember { mutableStateOf("") }
    var attachmentUrl by remember { mutableStateOf("") }
    var locationInput by remember { mutableStateOf("") }
    var chosenMediaType by remember { mutableStateOf("TEXT") }

    var isProgressing by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("What are we co-creating?", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = contentText,
                    onValueChange = { contentText = it },
                    placeholder = { Text("Express your thought... try 'free bitcoin' to test the spam shield!") },
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                )

                // Quick draft suggestions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                isProgressing = true
                                contentText = GeminiService.writePost("Co-creating modern connections")
                                isProgressing = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandSurfaceLighter, contentColor = BrandMint),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text("Draft post with AI", fontSize = 10.sp)
                    }

                    Button(
                        onClick = {
                            coroutineScope.launch {
                                isProgressing = true
                                val cap = GeminiService.generateCaption("breeze sky space")
                                contentText = "Vibe: $cap"
                                isProgressing = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandSurfaceLighter, contentColor = BrandCyan),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text("Caption ideas", fontSize = 10.sp)
                    }
                }

                // Attach Mock visual address url to let post look gorgeous
                OutlinedTextField(
                    value = attachmentUrl,
                    onValueChange = { attachmentUrl = it },
                    placeholder = { Text("Optional photo URL link") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                )

                OutlinedTextField(
                    value = locationInput,
                    onValueChange = { locationInput = it },
                    placeholder = { Text("Check-In Location (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                )

                if (attachmentUrl.isNotEmpty()) {
                    chosenMediaType = "IMAGE"
                }

                if (isProgressing) {
                    CircularProgressIndicator(color = BrandMint, modifier = Modifier.align(Alignment.CenterHorizontally))
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (contentText.isEmpty()) return@Button
                    isProgressing = true
                    coroutineScope.launch {
                        val result = repository.createPost(contentText, attachmentUrl, chosenMediaType, locationInput)
                        isProgressing = false
                        when (result) {
                            is PostResult.Success -> {
                                Toast.makeText(context, "🍃 Created successfully!", Toast.LENGTH_SHORT).show()
                            }
                            is PostResult.SpamFlagged -> {
                                Toast.makeText(context, "🚫 Post Flagged! Automatically routed to Admin review.", Toast.LENGTH_LONG).show()
                            }
                            is PostResult.Error -> {
                                Toast.makeText(context, "Error: ${result.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg)
            ) {
                Text("Publish to feed")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Discard", color = BrandGray)
            }
        },
        containerColor = BrandSurface
    )
}

// --- Ephemeral Storyviewer Overlay Screen ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoryViewerOverlay(
    story: StoryEntity,
    repository: AppRepository,
    onDismiss: () -> Unit
) {
    var tickProgress by remember { mutableStateOf(0f) }
    var isInteractivePaused by remember { mutableStateOf(false) }
    var isRepliesOpen by remember { mutableStateOf(false) }

    val likedStoryIds by repository.likedStoryIds.collectAsState()
    val isLiked = likedStoryIds.contains(story.id)
    val storyCommentsMap by repository.storyComments.collectAsState()
    val storyCommentsList = storyCommentsMap[story.id] ?: emptyList()

    LaunchedEffect(story.id, isInteractivePaused, isRepliesOpen) {
        while (tickProgress < 1f) {
            delay(100)
            if (!isInteractivePaused && !isRepliesOpen) {
                tickProgress += 0.02f
            }
        }
        if (tickProgress >= 1f) {
            onDismiss()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Full Image (Clicking on upper 80% of screen can dismiss the story)
        AsyncImage(
            model = story.mediaUrl,
            contentDescription = "Active story view layout",
            modifier = Modifier
                .fillMaxSize()
                .clickable { onDismiss() },
            contentScale = ContentScale.Crop
        )

        // Timing bar and User info at top
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 28.dp, start = 16.dp, end = 16.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .background(Color.White.copy(alpha = 0.4f), RoundedCornerShape(2.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(tickProgress)
                        .fillMaxHeight()
                        .background(BrandMint, RoundedCornerShape(2.dp))
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(32.dp).clip(CircleShape).background(Color.Gray)) {
                    AsyncImage(model = story.authorProfilePic, contentDescription = null, modifier = Modifier.fillMaxSize())
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(story.authorName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
            }
        }

        // Reply / Like / Comments Bar at the bottom
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.95f)),
                        startY = 0f
                    )
                )
                .padding(bottom = 32.dp, start = 16.dp, end = 16.dp, top = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val context = LocalContext.current
            val coroutineScope = rememberCoroutineScope()

            // Quick Emojis story reactions container
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("🔥", "😂", "🙌", "❤️", "😮", "❓").forEach { emoji ->
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.2f))
                            .clickable {
                                coroutineScope.launch {
                                    repository.reactToStory(story.id, emoji)
                                    Toast.makeText(context, "You reacted: $emoji 🌟", Toast.LENGTH_SHORT).show()
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(emoji, fontSize = 18.sp)
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                var replyText by remember { mutableStateOf("") }

                OutlinedTextField(
                    value = replyText,
                    onValueChange = {
                        replyText = it
                        isInteractivePaused = it.isNotEmpty()
                    },
                    placeholder = { Text("Reply to ${story.authorName}...", color = Color.Gray, fontSize = 13.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = BrandMint,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.4f),
                        focusedContainerColor = Color.Black.copy(alpha = 0.6f),
                        unfocusedContainerColor = Color.Black.copy(alpha = 0.3f)
                    ),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    trailingIcon = {
                        if (replyText.isNotEmpty()) {
                            IconButton(
                                onClick = {
                                    coroutineScope.launch {
                                        repository.addStoryComment(story.id, replyText)
                                        replyText = ""
                                        isInteractivePaused = false
                                    }
                                }
                            ) {
                                Icon(imageVector = Icons.Default.Send, contentDescription = "Send Reply", tint = BrandMint)
                            }
                        }
                    }
                )

                // Story Like button
                IconButton(
                    onClick = {
                        coroutineScope.launch {
                            repository.toggleStoryLike(story.id)
                        }
                    }
                ) {
                    Icon(
                        imageVector = if (isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Like Story",
                        tint = if (isLiked) BrandRed else Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }

                // View story comments/replies
                IconButton(
                    onClick = {
                        isRepliesOpen = true
                    }
                ) {
                    BadgedBox(
                        badge = {
                            if (storyCommentsList.isNotEmpty()) {
                                Badge(containerColor = BrandMint) {
                                    Text(
                                        storyCommentsList.size.toString(),
                                        color = BrandSurface,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ModeComment,
                            contentDescription = "Story Comments",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }

        // Story Remarks / Comments Overlay list Dialog
        if (isRepliesOpen) {
            AlertDialog(
                onDismissRequest = { isRepliesOpen = false },
                title = { Text("Story Feedback & Replies", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 280.dp)
                    ) {
                        LazyColumn(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (storyCommentsList.isEmpty()) {
                                item {
                                    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp), contentAlignment = Alignment.Center) {
                                        Text("No replies yet on this story. Send one above! ✨", style = MaterialTheme.typography.bodySmall.copy(color = BrandGray), textAlign = TextAlign.Center)
                                    }
                                }
                            } else {
                                items(storyCommentsList) { comment ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(28.dp)
                                                .clip(CircleShape)
                                                .background(Color.Gray)
                                        ) {
                                            AsyncImage(model = comment.authorProfilePic, contentDescription = null, modifier = Modifier.fillMaxSize())
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(comment.authorName, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = BrandOffWhite))
                                            Text(comment.content, style = MaterialTheme.typography.bodyMedium.copy(color = Color.White))
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { isRepliesOpen = false }) {
                        Text("Awesome", color = BrandMint)
                    }
                },
                containerColor = BrandSurface
            )
        }
    }
}

// --- Comments Drawer sheets ---

@Composable
fun CommentSheetDrawer(
    postId: Int,
    repository: AppRepository,
    onDismiss: () -> Unit
) {
    var rawText by remember { mutableStateOf("") }
    var selectedParentCommentId by remember { mutableStateOf<Int?>(null) }
    var selectedParentCommentAuthor by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    val comments by repository.dao.getCommentsForPostFlow(postId).collectAsState(initial = emptyList())
    val commentRepliesMap by repository.commentReplies.collectAsState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Comment Thread & Replies", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (comments.isEmpty()) {
                        item {
                            Text("No comments in the thread yet.", style = MaterialTheme.typography.bodySmall.copy(color = BrandGray))
                        }
                    } else {
                        items(comments) { comment ->
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.Top, modifier = Modifier.fillMaxWidth()) {
                                    Box(modifier = Modifier.size(28.dp).clip(CircleShape).background(BrandMuteBg)) {
                                        AsyncImage(model = comment.authorProfilePic, contentDescription = null)
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(comment.authorName, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = Color.White))
                                        Text(comment.content, style = MaterialTheme.typography.bodySmall.copy(color = BrandOffWhite))
                                        
                                        // Reply button trigger
                                        Text(
                                            text = "Reply",
                                            fontSize = 11.sp,
                                            color = BrandMint,
                                            modifier = Modifier
                                                .clickable {
                                                    selectedParentCommentId = comment.id
                                                    selectedParentCommentAuthor = comment.authorName
                                                }
                                                .padding(vertical = 4.dp)
                                        )
                                    }
                                }

                                // Threaded Replies
                                val replies = commentRepliesMap[comment.id] ?: emptyList()
                                if (replies.isNotEmpty()) {
                                    replies.forEach { reply ->
                                        Row(
                                            verticalAlignment = Alignment.Top,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(start = 32.dp, top = 6.dp)
                                        ) {
                                            Box(modifier = Modifier.size(20.dp).clip(CircleShape).background(BrandMuteBg)) {
                                                AsyncImage(model = reply.authorProfilePic, contentDescription = null)
                                            }
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Column {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(reply.authorName, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = BrandCyan))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("replied", fontSize = 9.sp, color = BrandGray)
                                                }
                                                Text(reply.content, style = MaterialTheme.typography.bodySmall.copy(color = BrandOffWhite))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                if (selectedParentCommentId != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BrandMuteBg, RoundedCornerShape(4.dp))
                            .padding(6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Replying to ${selectedParentCommentAuthor}",
                            fontSize = 11.sp,
                            color = BrandCyan,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cancel reply",
                            tint = BrandRed,
                            modifier = Modifier
                                .size(14.dp)
                                .clickable {
                                    selectedParentCommentId = null
                                    selectedParentCommentAuthor = ""
                                }
                        )
                    }
                }

                OutlinedTextField(
                    value = rawText,
                    onValueChange = { rawText = it },
                    placeholder = { Text(if (selectedParentCommentId != null) "Write reply..." else "Write comment...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (rawText.isEmpty()) return@Button
                    coroutineScope.launch {
                        val parentId = selectedParentCommentId
                        if (parentId != null) {
                            repository.addCommentReply(parentId, rawText)
                            selectedParentCommentId = null
                            selectedParentCommentAuthor = ""
                        } else {
                            repository.addComment(postId, rawText)
                        }
                        rawText = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg)
            ) {
                Text(if (selectedParentCommentId != null) "Reply" else "Publish")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = BrandGray)
            }
        },
        containerColor = BrandSurface
    )
}

// --- Zoomed Profile Photo Lightbox ---

@Composable
fun ProfilePhotoFullscreenLightbox(url: String?, onDismiss: () -> Unit) {
    if (url == null) return
    AlertDialog(
        onDismissRequest = onDismiss,
        title = null,
        text = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = url,
                    contentDescription = "Zoomed profile asset",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close Lightbox", color = BrandMint)
            }
        },
        containerColor = Color.Black.copy(alpha = 0.95f)
    )
}

// --- User Profile Details Sheet Dialog ---

@Composable
fun UserProfileViewerDialog(
    username: String,
    repository: AppRepository,
    onDismiss: () -> Unit,
    onPhotoClick: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var userDetails by remember(username) { mutableStateOf<UserEntity?>(null) }
    var isFollowing by remember(username) { mutableStateOf(false) }
    val allPosts by repository.dao.getAllPostsFlow().collectAsState(initial = emptyList())
    val activeStories by remember { repository.dao.getActiveStoriesFlow(System.currentTimeMillis() - 24 * 3600 * 1000) }.collectAsState(initial = emptyList())

    // Sub dialog states
    var showFollowersList by remember { mutableStateOf(false) }
    var showFollowingList by remember { mutableStateOf(false) }

    LaunchedEffect(username) {
        userDetails = repository.dao.getUserByUsername(username)
        val current = repository.currentUser.value?.username
        if (current != null) {
            isFollowing = repository.dao.isFollowing(current, username)
        }
    }

    val userPosts = remember(allPosts, username) {
        allPosts.filter { it.authorUsername == username && !it.isSpam }
    }
    val userStories = remember(activeStories, username) {
        activeStories.filter { it.authorUsername == username }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = null,
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    // Profile Header & Avatar
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(BrandSurface)
                            .border(2.dp, BrandMint, CircleShape)
                            .clickable { userDetails?.profilePicUrl?.let { onPhotoClick(it) } },
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = userDetails?.profilePicUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80",
                            contentDescription = "User Portrait",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = userDetails?.fullName ?: "Circle Member",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White)
                    )
                    Text(
                        text = "@$username",
                        style = MaterialTheme.typography.bodySmall.copy(color = BrandGray)
                    )
                }

                item {
                    // Bio
                    Text(
                        text = userDetails?.bio ?: "Connecting on Airmint space.",
                        style = MaterialTheme.typography.bodySmall.copy(color = BrandOffWhite, textAlign = TextAlign.Center),
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }

                item {
                    // Circle stats
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable { showFollowersList = true }
                        ) {
                            Text("Followers", fontSize = 10.sp, color = BrandGray)
                            Text(
                                text = if (username == "tech_master") "1.2K" else if (username == "aurora_travel") "940" else "128",
                                style = MaterialTheme.typography.bodyMedium.copy(color = BrandMint, fontWeight = FontWeight.Bold)
                            )
                        }
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable { showFollowingList = true }
                        ) {
                            Text("Following", fontSize = 10.sp, color = BrandGray)
                            Text(
                                text = if (username == "tech_master") "431" else if (username == "aurora_travel") "1.2K" else "95",
                                style = MaterialTheme.typography.bodyMedium.copy(color = BrandCyan, fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }

                item {
                    // Follow Unfollow toggle action button
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                repository.toggleFollow(username)
                                isFollowing = !isFollowing
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isFollowing) BrandMuteBg else BrandMint,
                            contentColor = if (isFollowing) BrandRed else BrandBg
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isFollowing) Icons.Default.PersonRemove else Icons.Default.PersonAdd,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isFollowing) "Unfollow Contacts" else "Connect & Follow")
                        }
                    }
                }

                // Ephemeral active Stories preview
                if (userStories.isNotEmpty()) {
                    item {
                        Column(horizontalAlignment = Alignment.Start, modifier = Modifier.fillMaxWidth()) {
                            Text("Active 24h Stories", fontSize = 11.sp, color = BrandGray, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                userStories.forEach { st ->
                                    Box(
                                        modifier = Modifier
                                            .size(50.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .border(1.5.dp, BrandMint, RoundedCornerShape(8.dp))
                                    ) {
                                        AsyncImage(
                                            model = st.mediaUrl,
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Posts header
                item {
                    Column(horizontalAlignment = Alignment.Start, modifier = Modifier.fillMaxWidth()) {
                        Text("Circle Posts & Updates (${userPosts.size})", fontSize = 11.sp, color = BrandGray, fontWeight = FontWeight.Bold)
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = BrandSurfaceLighter)
                    }
                }

                if (userPosts.isEmpty()) {
                    item {
                        Text("No active posts uploaded yet.", fontSize = 11.sp, color = BrandGray)
                    }
                } else {
                    items(userPosts) { pst ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BrandMuteBg),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(pst.content, fontSize = 12.sp, color = BrandOffWhite)
                                if (pst.mediaUrl.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    AsyncImage(
                                        model = pst.mediaUrl,
                                        contentDescription = null,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(100.dp)
                                            .clip(RoundedCornerShape(6.dp)),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close Profile", color = BrandMint)
            }
        },
        containerColor = BrandSurface
    )

    // Sub-dialogs for Followers / Following Lists
    if (showFollowersList || showFollowingList) {
        val titleText = if (showFollowersList) "Followers of @$username" else "Following list of @$username"
        val samplePeers = listOf(
            UserEntity("tech_master", "", "Devon Stark", "", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"),
            UserEntity("aurora_travel", "", "Aurora Sky", "", "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80"),
            UserEntity("pixel_chef", "", "Chef Leo", "", "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=150&q=80"),
            UserEntity("airmint_official", "", "Airmint Space", "", "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=150&q=80")
        ).filter { it.username != username }

        AlertDialog(
            onDismissRequest = {
                showFollowersList = false
                showFollowingList = false
            },
            title = { Text(titleText, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp) },
            text = {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 240.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(samplePeers) { u ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(modifier = Modifier.size(32.dp).clip(CircleShape)) {
                                AsyncImage(model = u.profilePicUrl, contentDescription = null, modifier = Modifier.fillMaxSize())
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(u.fullName, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = Color.White))
                                Text("@${u.username}", fontSize = 10.sp, color = BrandGray)
                            }
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        repository.toggleFollow(u.username)
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = BrandSurfaceLighter, contentColor = BrandMint),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text("Toggle", fontSize = 10.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showFollowersList = false
                    showFollowingList = false
                }) {
                    Text("Done", color = BrandMint)
                }
            },
            containerColor = BrandSurfaceLighter
        )
    }
}

// --- Notifications Drawer Sheet ---

@Composable
fun NotificationsSheetDrawer(
    repository: AppRepository,
    onDismiss: () -> Unit
) {
    val currentUser by repository.currentUser.collectAsState()
    val coroutineScope = rememberCoroutineScope()
    val notificationsList by remember(currentUser) {
        repository.dao.getNotificationsFlow(currentUser?.username ?: "")
    }.collectAsState(initial = emptyList())

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Bell Circle Notifications", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                if (notificationsList.isNotEmpty()) {
                    TextButton(onClick = {
                        coroutineScope.launch {
                            repository.dao.clearUserNotifications(currentUser?.username ?: "")
                        }
                    }) {
                        Text("Clear All", color = BrandRed, fontSize = 11.sp)
                    }
                }
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 350.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (notificationsList.isEmpty()) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(imageVector = Icons.Default.NotificationsNone, contentDescription = null, tint = BrandGray, modifier = Modifier.size(40.dp))
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Your radar is completely quiet right now.", fontSize = 11.sp, color = BrandGray, textAlign = TextAlign.Center)
                        }
                    }
                } else {
                    items(notificationsList) { notif ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BrandSurfaceLighter),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val iconTint = when (notif.type) {
                                    "LIKE" -> BrandRed
                                    "COMMENT" -> BrandCyan
                                    "FOLLOW" -> BrandMint
                                    "MESSAGE" -> BrandMint
                                    "STORY_REACTION" -> Color(0xFFFF8800)
                                    else -> BrandMint
                                }
                                val iconVector = when (notif.type) {
                                    "LIKE" -> Icons.Default.Favorite
                                    "COMMENT" -> Icons.Default.Comment
                                    "FOLLOW" -> Icons.Default.PersonAdd
                                    "MESSAGE" -> Icons.Default.Mail
                                    "STORY_REACTION" -> Icons.Default.Celebration
                                    else -> Icons.Default.Info
                                }
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(iconTint.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(imageVector = iconVector, contentDescription = null, tint = iconTint, modifier = Modifier.size(18.dp))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = notif.message, fontSize = 11.sp, color = BrandOffWhite)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = android.text.format.DateUtils.getRelativeTimeSpanString(notif.timestamp).toString(),
                                        fontSize = 9.sp,
                                        color = BrandGray
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Dismiss", color = BrandMint)
            }
        },
        containerColor = BrandSurface
    )
}

// --- Sports Section Stadium Hub Overlay ---

@Composable
fun SportsStadiumHubOverlay(
    repository: AppRepository,
    onDismiss: () -> Unit
) {
    var selectedSportsTab by remember { mutableStateOf(0) } // 0: Scores, 1: News, 2: Videos, 3: Stadium Call
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    // Interactive simulated cricket stadium game state
    var matchScoreA by remember { mutableStateOf(182) }
    var matchWicketsA by remember { mutableStateOf(3) }
    var matchOvers by remember { mutableStateOf(18.4) }
    var pointsB by remember { mutableStateOf(178) }

    // Interactive Football Game state
    var footballRealMadrid by remember { mutableStateOf(2) }
    var footballBarca by remember { mutableStateOf(1) }

    // Commentary tick lists
    val defaultCommentaries = remember {
        mutableStateListOf(
            "• Live crowd chanting intensely in Airmint Shibuya Stadium!",
            "• Match updating live in real-time. Target: 179 runs needed.",
            "• Broadcast commentary link enabled under Lounge call tab."
        )
    }

    // Cricket Commentary tick updates simulation
    LaunchedEffect(true) {
        while (true) {
            delay(5000)
            if (matchOvers < 20.0) {
                val rem = (matchOvers * 10).toInt() % 10
                if (rem == 5) {
                    matchOvers = ((matchOvers.toInt() + 1).toDouble())
                } else {
                    matchOvers += 0.1
                }
                matchScoreA += (1..4).random()
                if ((1..100).random() < 12) {
                    matchWicketsA = (matchWicketsA + 1).coerceAtMost(10)
                    defaultCommentaries.add(0, "🏏 WICKET OUT! Chennai strikes back at Over ${String.format("%.1f", matchOvers)}!")
                } else {
                    defaultCommentaries.add(0, "• Over ${String.format("%.1f", matchOvers)}: Striker secures runs on the offside.")
                }
            }
        }
    }

    // News Filter and search state
    var newsSearchQuery by remember { mutableStateOf("") }
    var selectedNewsCategory by remember { mutableStateOf("All") } // All, Esports, Football, Basketball, Cricket

    // Video Highlight Player States
    var activePlayingVideoName by remember { mutableStateOf<String?>(null) }
    var videoPlaybackTimeSeconds by remember { mutableStateOf(0) }
    var isVideoMuted by remember { mutableStateOf(false) }

    // Call states
    var isCallActive by remember { mutableStateOf(false) }
    var callMode by remember { mutableStateOf("VIDEO") } // VOICE or VIDEO
    var isMuted by remember { mutableStateOf(false) }
    var isCameraFront by remember { mutableStateOf(true) }
    var callDurationSeconds by remember { mutableStateOf(0) }

    // Call Timer clock ticks
    LaunchedEffect(isCallActive) {
        if (isCallActive) {
            callDurationSeconds = 0
            while (isCallActive) {
                delay(1000)
                callDurationSeconds++
            }
        }
    }

    // Video Player ticks
    LaunchedEffect(activePlayingVideoName) {
        if (activePlayingVideoName != null) {
            videoPlaybackTimeSeconds = 0
            while (activePlayingVideoName != null) {
                delay(1000)
                videoPlaybackTimeSeconds = (videoPlaybackTimeSeconds + 1) % 15
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.EmojiEvents, contentDescription = null, tint = BrandMint, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Airmint Sports Arena", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                Spacer(modifier = Modifier.height(10.dp))
                TabRow(
                    selectedTabIndex = selectedSportsTab,
                    containerColor = Color.Transparent,
                    contentColor = BrandMint,
                    divider = {}
                ) {
                    Tab(selected = selectedSportsTab == 0, onClick = { selectedSportsTab = 0 }) {
                        Text("Scores", fontSize = 10.sp, modifier = Modifier.padding(vertical = 6.dp), color = if (selectedSportsTab == 0) BrandMint else BrandGray)
                    }
                    Tab(selected = selectedSportsTab == 1, onClick = { selectedSportsTab = 1 }) {
                        Text("News", fontSize = 10.sp, modifier = Modifier.padding(vertical = 6.dp), color = if (selectedSportsTab == 1) BrandMint else BrandGray)
                    }
                    Tab(selected = selectedSportsTab == 2, onClick = { selectedSportsTab = 2 }) {
                        Text("Videos", fontSize = 10.sp, modifier = Modifier.padding(vertical = 6.dp), color = if (selectedSportsTab == 2) BrandMint else BrandGray)
                    }
                    Tab(selected = selectedSportsTab == 3, onClick = { selectedSportsTab = 3 }) {
                        Text("Calls", fontSize = 10.sp, modifier = Modifier.padding(vertical = 6.dp), color = if (selectedSportsTab == 3) BrandMint else BrandGray)
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                when (selectedSportsTab) {
                    0 -> {
                        // Live Scores & commentary Section
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BrandSurfaceLighter),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color.Red))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("LIVE CRICKET FINALS", fontSize = 9.sp, color = Color.Red, fontWeight = FontWeight.Bold)
                                    }
                                    Text("Airmint Arena", fontSize = 8.sp, color = BrandMint)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceAround,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Mumbai", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                                        Text("$matchScoreA/$matchWicketsA", style = MaterialTheme.typography.titleMedium.copy(color = BrandMint, fontWeight = FontWeight.Bold))
                                        Text("($matchOvers Overs)", fontSize = 9.sp, color = BrandGray)
                                    }
                                    Text("vs", color = BrandGray, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Chennai", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                                        Text("$pointsB/5", style = MaterialTheme.typography.titleMedium.copy(color = BrandCyan, fontWeight = FontWeight.Bold))
                                        Text("(20.0 Overs)", fontSize = 9.sp, color = BrandGray)
                                    }
                                }
                            }
                        }

                        // Football card
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BrandSurfaceLighter),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("EL CLÁSICO DERBY", fontSize = 9.sp, color = BrandCyan, fontWeight = FontWeight.Bold)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("R. Madrid", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(footballRealMadrid.toString(), fontSize = 13.sp, color = BrandMint, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("-", color = Color.Gray)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(footballBarca.toString(), fontSize = 13.sp, color = BrandMint, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Barcelona", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Button(
                                    onClick = {
                                        footballRealMadrid++
                                        defaultCommentaries.add(0, "⚽ GOAL MADRID! Real Madrid strikes! Spectacular bicycle kick goal! Score is now $footballRealMadrid - $footballBarca!")
                                        Toast.makeText(context, "⚽ GOAL madrid simulated!", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = BrandMint.copy(alpha = 0.2f), contentColor = BrandMint),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text("Sim Goal", fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Commentary ticker Stream
                        Text("Live Commentary Stream", fontSize = 10.sp, color = BrandGray, fontWeight = FontWeight.Bold)
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BrandMuteBg),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(90.dp)
                                    .padding(8.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                items(defaultCommentaries) { comment ->
                                    Text(comment, fontSize = 9.sp, color = if (comment.contains("GOAL") || comment.contains("WICKET")) BrandMint else BrandOffWhite)
                                }
                            }
                        }
                    }

                    1 -> {
                        // News Wire Tab with Category selection & search filters
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            // Keyword search bar
                            OutlinedTextField(
                                value = newsSearchQuery,
                                onValueChange = { newsSearchQuery = it },
                                placeholder = { Text("Search news wire keyword...", fontSize = 11.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrandMint, focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                            )

                            // Quick Sports Category chips row
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items(listOf("All", "Esports", "Football", "Basketball", "Cricket")) { category ->
                                    val isSelected = selectedNewsCategory == category
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(if (isSelected) BrandMint.copy(alpha = 0.2f) else BrandSurfaceLighter)
                                            .border(1.dp, if (isSelected) BrandMint else Color.Transparent, RoundedCornerShape(12.dp))
                                            .clickable { selectedNewsCategory = category }
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text(category, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (isSelected) BrandMint else BrandGray)
                                    }
                                }
                            }

                            // News output list
                            val allNewsItems = listOf(
                                Triple("Airmint e-Sports Championship registration starts next monday!", "Esports", "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=150&q=80"),
                                Triple("Real Madrid vs Barcelona historical football updates stats", "Football", "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=150&q=80"),
                                Triple("Lakers edge past Celtics in dramatic double-overtime climax", "Basketball", "https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&w=150&q=80"),
                                Triple("India retains border-gavaskar cricket trophy after outstanding win", "Cricket", "https://images.unsplash.com/photo-1540747737956-378724044282?auto=format&fit=crop&w=150&q=80")
                            )

                            val filteredNews = allNewsItems.filter { (title, cat, _) ->
                                (selectedNewsCategory == "All" || selectedNewsCategory == cat) &&
                                        (newsSearchQuery.isBlank() || title.contains(newsSearchQuery, ignoreCase = true))
                            }

                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (filteredNews.isEmpty()) {
                                    item {
                                        Text("No matching wire updates found.", fontSize = 10.sp, color = BrandGray, modifier = Modifier.padding(14.dp))
                                    }
                                }
                                items(filteredNews) { (title, cat, imgUrl) ->
                                    Card(colors = CardDefaults.cardColors(containerColor = BrandSurfaceLighter)) {
                                        Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(45.dp)
                                                    .clip(RoundedCornerShape(6.dp))
                                            ) {
                                                AsyncImage(model = imgUrl, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(title, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 2)
                                                Text("Sports Category: $cat • Verified Hub Update", fontSize = 8.sp, color = BrandMint)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        // Sports Videos tab (Highlight Clips Player)
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            if (activePlayingVideoName == null) {
                                Text("Aesthetic Highlight Reels", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                Text("Watch professional sports game-changing milestones securely below:", fontSize = 9.sp, color = BrandGray)

                                val highlightVideos = listOf(
                                    "F1 Oracle RedBull Pitstop Overdrive" to "🏎️ Formula One Live Highlight",
                                    "Valorant VCT Masters 1v3 Matchpoint Clutch" to "🎮 Esports Finals Arena",
                                    "X-Games Skate Megaramp Aerial Flight" to "🛹 Extreme Action Sports"
                                )

                                highlightVideos.forEach { (title, label) ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { activePlayingVideoName = title },
                                        colors = CardDefaults.cardColors(containerColor = BrandSurfaceLighter)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(36.dp)
                                                        .clip(CircleShape)
                                                        .background(BrandMint.copy(alpha = 0.2f)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = BrandMint, modifier = Modifier.size(18.dp))
                                                }
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Column {
                                                    Text(title, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                                    Text(label, fontSize = 8.sp, color = BrandGray)
                                                }
                                            }
                                            Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, tint = BrandGray, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            } else {
                                // Customized Videoplayback HUD simulation
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color.Black),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(activePlayingVideoName!!, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BrandMint)
                                            IconButton(onClick = { activePlayingVideoName = null }, modifier = Modifier.size(24.dp)) {
                                                Icon(imageVector = Icons.Default.Close, contentDescription = null, tint = Color.Red, modifier = Modifier.size(16.dp))
                                            }
                                        }

                                        // Video screen mock
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(130.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(BrandSurface)
                                        ) {
                                            AsyncImage(
                                                model = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=300&q=80",
                                                contentDescription = null,
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop,
                                                alpha = 0.4f
                                            )
                                            // Progress Indicator lines
                                            CircularProgressIndicator(
                                                color = BrandMint,
                                                modifier = Modifier
                                                    .size(36.dp)
                                                    .align(Alignment.Center)
                                            )
                                        }

                                        // Seek and Player Controls
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                "0:${videoPlaybackTimeSeconds.toString().padStart(2, '0')} / 0:15",
                                                fontSize = 9.sp,
                                                color = Color.White
                                            )

                                            IconButton(onClick = { isVideoMuted = !isVideoMuted }, modifier = Modifier.size(24.dp)) {
                                                Icon(
                                                    imageVector = if (isVideoMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                                                    contentDescription = null,
                                                    tint = Color.White,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }

                                        LinearProgressIndicator(
                                            progress = { videoPlaybackTimeSeconds / 15f },
                                            modifier = Modifier.fillMaxWidth(),
                                            color = BrandMint,
                                            trackColor = BrandGray
                                        )
                                    }
                                }
                            }
                        }
                    }

                    3 -> {
                        // Stadium Call Tab: Voice Lounge and Video Rooms supporting direct calls
                        if (isCallActive) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = if (callMode == "VIDEO") "Active Stadium Video Room Lounge" else "Active Stadium Voice Lounge",
                                    color = BrandCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )

                                Text(
                                    text = "Call Timer Duration: ${callDurationSeconds / 60}:${String.format("%02d", callDurationSeconds % 60)}",
                                    fontSize = 10.sp,
                                    color = BrandMint,
                                    fontWeight = FontWeight.Bold
                                )

                                if (callMode == "VIDEO") {
                                    // Fan video call grid
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        // Self Stream Card
                                        Card(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(95.dp),
                                            colors = CardDefaults.cardColors(containerColor = BrandMuteBg)
                                        ) {
                                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                                if (isCameraFront) {
                                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                                        drawRect(Brush.radialGradient(listOf(BrandCyan.copy(alpha = 0.5f), Color.Transparent)))
                                                    }
                                                    Text("Self Stream (Front)", fontSize = 8.sp, color = Color.White)
                                                } else {
                                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                                        drawRect(Brush.radialGradient(listOf(BrandMint.copy(alpha = 0.5f), Color.Transparent)))
                                                    }
                                                    Text("Rear Arena view", fontSize = 8.sp, color = BrandGray)
                                                }
                                            }
                                        }

                                        // Remote subscriber Card
                                        Card(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(95.dp),
                                            colors = CardDefaults.cardColors(containerColor = BrandSurfaceLighter)
                                        ) {
                                            Box(modifier = Modifier.fillMaxSize()) {
                                                AsyncImage(
                                                    model = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80",
                                                    contentDescription = null,
                                                    modifier = Modifier.fillMaxSize(),
                                                    contentScale = ContentScale.Crop
                                                )
                                                Box(
                                                    modifier = Modifier
                                                        .align(Alignment.BottomStart)
                                                        .background(Color.Black.copy(alpha = 0.6f))
                                                        .padding(2.dp)
                                                ) {
                                                    Text(" नेहा (Sports Cohort)", fontSize = 8.sp, color = Color.White)
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    // Voice call waveform visual representation
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = BrandSurfaceLighter),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier.size(54.dp).clip(CircleShape).background(BrandMint),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(imageVector = Icons.Default.Mic, contentDescription = null, tint = BrandBg, modifier = Modifier.size(28.dp))
                                            }

                                            Text("Aesthetic Commentary Frequency Nodes Enabled", fontSize = 9.sp, color = BrandGray)

                                            Row(
                                                modifier = Modifier.height(18.dp),
                                                horizontalArrangement = Arrangement.spacedBy(3.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                repeat(14) {
                                                    Box(
                                                        modifier = Modifier
                                                            .width(2.5.dp)
                                                            .fillMaxHeight(remember(callDurationSeconds) { (2..10).random() / 10f })
                                                            .background(BrandMint)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                // Interactive call settings Row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly
                                ) {
                                    Button(
                                        onClick = { isMuted = !isMuted },
                                        colors = ButtonDefaults.buttonColors(containerColor = if (isMuted) Color.Red else BrandMuteBg),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(if (isMuted) "Unmute" else "Mute Mic", fontSize = 8.sp)
                                    }

                                    if (callMode == "VIDEO") {
                                        Button(
                                            onClick = { isCameraFront = !isCameraFront },
                                            colors = ButtonDefaults.buttonColors(containerColor = BrandSurfaceLighter),
                                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text("Flip Cam", fontSize = 8.sp)
                                        }
                                    }

                                    Button(
                                        onClick = { isCallActive = false },
                                        colors = ButtonDefaults.buttonColors(containerColor = BrandRed, contentColor = Color.White),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("Hang Up", fontSize = 8.sp)
                                    }
                                }
                            }
                        } else {
                            // Call launcher hub
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text("Lounge Commentary Rooms", fontSize = 11.sp, color = BrandGray, fontWeight = FontWeight.Bold)
                                Text("Sync live with cohort voice comments or fan video feedback screens during the finals!", fontSize = 10.sp, color = BrandOffWhite, textAlign = TextAlign.Center)

                                Button(
                                    onClick = {
                                        callMode = "VOICE"
                                        isCallActive = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = BrandCyan, contentColor = BrandBg),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(imageVector = Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Join Commentary Voice Lounge")
                                }

                                Button(
                                    onClick = {
                                        callMode = "VIDEO"
                                        isCallActive = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(imageVector = Icons.Default.VideoCall, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Join Stadium Companion Video Lounge")
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = BrandMint, contentColor = BrandBg)
            ) {
                Text("Exit Arena")
            }
        },
        containerColor = BrandSurface
    )
}
